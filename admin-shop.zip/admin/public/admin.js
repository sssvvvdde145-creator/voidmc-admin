const $=s=>document.querySelector(s);
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const money=n=>'₹'+Number(n||0).toLocaleString('en-IN');
const toast=t=>{const e=$('#toast');e.textContent=t;e.classList.add('show');setTimeout(()=>e.classList.remove('show'),2400)};
async function api(path,method='GET',data){
  const r=await fetch('/api/admin/'+path,{method,headers:{'Content-Type':'application/json','X-VM-Admin':'1'},body:data?JSON.stringify(data):undefined});
  const d=await r.json().catch(()=>({}));
  if(r.status===401&&path!=='login'){lock();throw Error('Session expired. Please sign in again.')}
  if(!r.ok)throw Error(d.error||'Request failed');return d;
}
const lock=()=>{$('#app').hidden=true;$('#login').hidden=false};
const unlock=()=>{$('#login').hidden=true;$('#app').hidden=false;go('overview')};
const tag=s=>`<span class="tag ${esc(s)}">${esc(String(s).replace('_',' ').toUpperCase())}</span>`;
const items=o=>o.items.map(i=>`${esc(i.name)} ×${i.qty}`).join(', ');
const run=fn=>async(...a)=>{try{await fn(...a)}catch(e){toast(e.message)}};
let tab='overview',musicPreviewUrl='';
function go(t){tab=t;document.querySelectorAll('#nav button').forEach(b=>b.classList.toggle('on',b.dataset.tab===t));views[t]().catch(e=>toast(e.message))}
function set(html){$('#view').innerHTML=html}
function orderCard(o){return `<div class="row"><div><b>${esc(o.id)}</b> · ${esc(o.customer_name)} ${tag(o.status)}<br><span class="muted">${items(o)} · ${money(o.total)}${o.coupon?' · coupon '+esc(o.coupon):''}<br>${esc(o.email)} · ${esc(o.phone)} · ${esc(o.location)}<br>Minecraft: <b>${esc(o.minecraft_username||'')}</b><br>${esc(new Date(o.created_at).toLocaleString())}</span>${o.code?`<br><span class="code">${esc(o.code)}</span>`:''}</div></div>`}
function bindStatus(o){document.querySelectorAll('[data-st]').forEach(b=>b.onclick=run(async()=>{await api(`orders/${b.dataset.id}/status`,'POST',{status:b.dataset.st});toast('Order '+b.dataset.st);go(tab)}))}
const views={
async overview(){const s=await api('stats'),by=Object.fromEntries(s.byStatus.map(x=>[x.status,x]));const g=k=>by[k]||{n:0,s:0};
  set(`<h2>Overview</h2>${s.maintenance?'<div class="maint-banner">🛠 MAINTENANCE MODE IS ON — the shop is closed to customers. <button class="sm" data-goto="maintenance">Manage</button></div>':''}<div class="grid"><div class="stat">Awaiting payment<b>${g('awaiting_payment').n}</b></div><div class="stat">Codes to verify<b>${g('payment_submitted').n}</b></div><div class="stat">Verified orders<b>${g('verified').n}</b></div><div class="stat">Verified revenue<b>${money(g('verified').s)}</b></div><div class="stat">Active coupons<b>${s.activeCoupons}</b></div></div>`);document.querySelectorAll('[data-goto]').forEach(b=>b.onclick=()=>go(b.dataset.goto))},
async verify(){set(`<h2>Verify Payment Code</h2><div class="panel"><div class="form"><input id="vc" maxlength="20" placeholder="VM••••••••••••••••HE" autocomplete="off"><button class="btn" id="vb">Verify</button></div><div id="vr"></div></div>`);
  const check=run(async()=>{const d=await api('verify','POST',{code:$('#vc').value});
    $('#vr').innerHTML=d.valid?`<div class="result ok"><h3>✅ VALID CODE</h3>${orderCard(d)}<div class="form"><button class="sm" data-st="verified" data-id="${esc(d.id)}">Mark payment verified</button><button class="sm red" data-st="rejected" data-id="${esc(d.id)}">Reject</button></div></div>`:'<div class="result bad"><h3>❌ INVALID CODE</h3><span class="muted">No order matches this code.</span></div>';bindStatus()});
  $('#vb').onclick=check;$('#vc').onkeydown=e=>{if(e.key==='Enter')check()}},
async orders(){const rows=await api('orders');set(`<h2>Orders</h2><div class="panel">${rows.map(o=>`${orderCard(o)}<div class="form order-actions">${o.code&&o.status!=='verified'&&o.status!=='rejected'?`<button class="sm" data-st="verified" data-id="${esc(o.id)}">Verify</button><button class="sm red" data-st="rejected" data-id="${esc(o.id)}">Reject</button>`:''}<button class="sm red" data-order-delete="${esc(o.id)}">Delete order</button></div>`).join('')||'<p class="muted">No orders yet.</p>'}</div>`);bindStatus();document.querySelectorAll('[data-order-delete]').forEach(b=>b.onclick=run(async()=>{if(confirm('Permanently delete order '+b.dataset.orderDelete+'?')){await api('orders/'+b.dataset.orderDelete,'DELETE');toast('Order deleted');go('orders')}}))},
async free(){const d=await api('free-rank');
  set(`<h2>Free Rank</h2><div class="grid"><div class="stat">Status<b>${d.enabled?'ON':'OFF'}</b></div><div class="stat">Claimed<b>${d.claimed}/${d.max}</b></div><div class="stat">Remaining slots<b>${d.remaining}</b></div></div>
  <div class="panel spaced"><h3>Edit Free Rank</h3><p class="muted">Changes go live on the store immediately. No code edits needed.</p>
  <div class="fields"><label>Rank name<input id="fr-name" maxlength="24" value="${esc(d.name)}"></label><label>Rank price (₹, shown as the rank's normal value; 0 = no value shown)<input id="fr-price" type="number" min="0" max="100000" step="1" value="${d.price}"></label><label>Maximum claims<input id="fr-max" type="number" min="0" max="1000" step="1" value="${d.max}"></label><label>Free Rank option<select id="fr-enabled"><option value="1" ${d.enabled?'selected':''}>ON (visible &amp; claimable)</option><option value="0" ${d.enabled?'':'selected'}>OFF (hidden on store)</option></select></label><label class="wide">Description<input id="fr-desc" maxlength="120" value="${esc(d.description)}"></label></div>
  <button class="btn" id="fr-save">Save Free Rank</button></div>
  <div class="panel spaced"><h3>Players who claimed (${d.claims.length})</h3>${d.claims.map((c,i)=>`<div class="row"><div><b>#${i+1} · ${esc(c.minecraft_username)}</b> <span class="tag">${esc(c.rank_name)}</span><br><span class="muted">${esc(c.customer_name)} · ${esc(c.email)} · ${esc(c.phone)} · ${esc(c.location)}<br>${esc(new Date(c.created_at).toLocaleString())} · ID ${esc(c.id)} · ${esc(c.status||'active').toUpperCase()}</span></div><div>${c.status==='cancelled'?'<span class="muted">Cancelled</span>':`<button class="sm red" data-cd="${esc(c.id)}" data-cu="${esc(c.minecraft_username)}">Cancel claim</button>`}</div></div>`).join('')||'<p class="muted">No claims yet.</p>'}<p class="muted">Removing a claim frees its slot.</p></div>`);
  $('#fr-save').onclick=run(async()=>{await api('free-rank','PUT',{name:$('#fr-name').value,price:Number($('#fr-price').value),max:Number($('#fr-max').value),description:$('#fr-desc').value,enabled:$('#fr-enabled').value==='1'});toast('Free Rank saved');go('free')});
  document.querySelectorAll('[data-cd]').forEach(b=>b.onclick=run(async()=>{if(confirm('Remove the claim by '+b.dataset.cu+'? This frees one slot.')){await api('free-claims/'+b.dataset.cd,'DELETE');toast('Claim removed');go('free')}}))},
async coupons(){const rows=await api('coupons');
  set(`<h2>Coupons</h2><div class="panel"><h3>Random coupon</h3><div class="form"><input id="rp" type="number" min="1" max="90" placeholder="Discount %"><button class="btn" id="rb">Generate random (6 chars)</button></div><h3>Custom coupon</h3><div class="form"><input id="cc" maxlength="6" placeholder="6-character code"><input id="cp" type="number" min="1" max="90" placeholder="Discount %"><button class="btn ghost" id="cb">Create</button></div>${rows.map(c=>`<div class="row"><div><b class="code">${esc(c.code)}</b> · ${c.discount}% off ${tag(c.active?'verified':'rejected').replace(/VERIFIED|REJECTED/,c.active?'ACTIVE':'INACTIVE')}</div><div><button class="sm" data-t="${esc(c.code)}" data-a="${c.active?0:1}">${c.active?'Deactivate':'Activate'}</button> <button class="sm red" data-d="${esc(c.code)}">Delete</button></div></div>`).join('')||'<p class="muted">No coupons yet.</p>'}</div>`);
  $('#rb').onclick=run(async()=>{const d=await api('coupons/random','POST',{discount:Number($('#rp').value)});toast('Created '+d.code);go('coupons')});
  $('#cb').onclick=run(async()=>{await api('coupons','POST',{code:$('#cc').value,discount:Number($('#cp').value)});toast('Coupon created');go('coupons')});
  document.querySelectorAll('[data-t]').forEach(b=>b.onclick=run(async()=>{await api('coupons/'+b.dataset.t,'PATCH',{active:b.dataset.a==='1'});go('coupons')}));
  document.querySelectorAll('[data-d]').forEach(b=>b.onclick=run(async()=>{if(confirm('Delete coupon '+b.dataset.d+'?')){await api('coupons/'+b.dataset.d,'DELETE');go('coupons')}}))},
async ranks(){const [rows,categories]=await Promise.all([api('ranks'),api('categories')]);
  const catOpts=categories.map(c=>`<option value="${esc(c.name)}">${esc(c.name)}</option>`).join('');
  set(`<h2>Ranks & Categories</h2><div class="panel"><h3>Create category</h3><div class="form"><input id="new-category" placeholder="e.g. Ranks, Kits"><button class="btn" id="create-category">Create category</button></div><h3>Ranks</h3>${rows.map(r=>`<div class="edit" data-r="${esc(r.name)}"><b>${esc(r.name)}</b><input data-f="price" type="number" value="${r.price}" aria-label="Price"><input data-f="tier" value="${esc(r.tier)}" aria-label="Tier"><input data-f="description" value="${esc(r.description)}" aria-label="Description"><input data-f="icon" value="${esc(r.icon)}" maxlength="4" aria-label="Icon"><select data-f="category">${categories.map(c=>`<option value="${esc(c.name)}" ${c.name===(r.category||'Ranks')?'selected':''}>${esc(c.name)}</option>`).join('')}</select><span><button class="sm" data-save>Save</button> <button class="sm ghost" data-act>${r.active?'Hide':'Show'}</button> <button class="sm red" data-del>Delete</button></span></div>`).join('')}<h3>Add rank</h3><div class="form"><input id="nn" placeholder="NAME" maxlength="16"><input id="np" type="number" min="1" placeholder="Price ₹"><input id="nt" placeholder="Tier label"><input id="nd" placeholder="Description"><select id="nc">${categories.length?catOpts:'<option value="Ranks">Ranks</option>'}</select><button class="btn" id="na">Add rank</button></div></div>`);
  $('#create-category').onclick=run(async()=>{await api('categories','POST',{name:$('#new-category').value});toast('Category created');go('ranks')});
  const read=el=>Object.fromEntries([...el.querySelectorAll('[data-f]')].map(i=>[i.dataset.f,i.dataset.f==='price'?Number(i.value):i.value]));
  const byName=Object.fromEntries(rows.map(r=>[r.name,r]));
  document.querySelectorAll('[data-r]').forEach(el=>{const n=el.dataset.r,cur=byName[n];
    el.querySelector('[data-save]').onclick=run(async()=>{await api('ranks/'+n,'PUT',{...read(el),active:!!cur.active,sort:cur.sort});toast(n+' saved');go('ranks')});
    el.querySelector('[data-act]').onclick=run(async()=>{await api('ranks/'+n,'PUT',{...read(el),active:!cur.active,sort:cur.sort});go('ranks')});
    el.querySelector('[data-del]').onclick=run(async()=>{if(confirm('Delete rank '+n+'?')){await api('ranks/'+n,'DELETE');go('ranks')}})});
  $('#na').onclick=run(async()=>{await api('ranks','POST',{name:$('#nn').value,price:Number($('#np').value),tier:$('#nt').value,description:$('#nd').value,category:$('#nc').value,sort:rows.length+1});toast('Rank added');go('ranks')})},
async announcements(){const rows=await api('announcements');set(`<h2>Live Announcements</h2><div class="panel"><h3>Create announcement</h3><textarea id="ann-new" maxlength="240" placeholder="Write a shop-wide announcement..."></textarea><label class="check"><input id="ann-new-active" type="checkbox" checked> Active immediately</label><button class="btn" id="ann-create">Publish announcement</button></div><div class="panel spaced"><h3>Existing announcements</h3>${rows.map(a=>`<div class="row ann-row" data-ann="${esc(a.id)}"><div><textarea data-ann-message maxlength="240">${esc(a.message)}</textarea><label><input type="checkbox" data-ann-active ${a.active?'checked':''}> Active</label></div><div><button class="sm" data-ann-save>Save</button> <button class="sm red" data-ann-delete>Delete</button></div></div>`).join('')||'<p class="muted">No announcements yet.</p>'}</div>`);
  $('#ann-create').onclick=run(async()=>{await api('announcements','POST',{message:$('#ann-new').value,active:$('#ann-new-active').checked});toast('Announcement published');go('announcements')});
  document.querySelectorAll('[data-ann]').forEach(el=>{el.querySelector('[data-ann-save]').onclick=run(async()=>{await api('announcements/'+el.dataset.ann,'PUT',{message:el.querySelector('[data-ann-message]').value,active:el.querySelector('[data-ann-active]').checked});toast('Announcement updated');go('announcements')});el.querySelector('[data-ann-delete]').onclick=run(async()=>{if(confirm('Delete this announcement?')){await api('announcements/'+el.dataset.ann,'DELETE');go('announcements')}})});
},
async maintenance(){const m=await api('maintenance');
  set(`<h2>Maintenance Mode</h2><div class="panel"><div class="maint-head"><div><h3>Shop status: <span id="mt-state" class="mt-state ${m.enabled?'on':'off'}">${m.enabled?'MAINTENANCE ON':'SHOP LIVE'}</span></h3><p class="muted">${m.enabled?'Customers see the full-screen MAINTENANCE page. New orders and Free Rank claims are blocked.':'The shop is open and working normally.'}<br>Admin panel always stays accessible.${m.updatedAt?'<br>Last changed: '+esc(new Date(m.updatedAt).toLocaleString()):''}</p></div><label class="switch" title="Toggle Maintenance Mode"><input type="checkbox" id="mt-toggle" ${m.enabled?'checked':''}><span class="slider"></span></label></div></div>
  <div class="panel spaced"><h3>Maintenance reason / message</h3><p class="muted">Shown to customers on the maintenance screen. Changes apply instantly.</p><textarea id="mt-msg" maxlength="500" placeholder="Why is the shop under maintenance?">${esc(m.message)}</textarea><p class="muted"><span id="mt-count">${m.message.length}</span>/500</p><button class="btn" id="mt-save">Save message</button> <a class="btn ghost linkbtn" href="https://shop.voidmc.bond" target="_blank" rel="noreferrer">Open shop ↗</a></div>`);
  const msg=$('#mt-msg');msg.oninput=()=>{$('#mt-count').textContent=msg.value.length};
  $('#mt-save').onclick=run(async()=>{if(!msg.value.trim())throw Error('Enter a maintenance reason/message.');await api('maintenance','PUT',{message:msg.value});toast('Message saved — live now');go('maintenance')});
  $('#mt-toggle').onchange=async e=>{const want=e.target.checked;try{if(want&&!confirm('Turn Maintenance Mode ON? Customers will immediately be blocked from the shop.')){e.target.checked=false;return}if(!msg.value.trim())throw Error('Enter a maintenance reason/message first.');await api('maintenance','PUT',{enabled:want,message:msg.value});toast(want?'Maintenance ON — shop closed':'Maintenance OFF — shop live');go('maintenance')}catch(err){e.target.checked=!want;toast(err.message)}}},
async settings(){const s=await api('settings');
  set(`<h2>Website Branding</h2><div class="panel"><h3>Website Logo</h3><p class="muted">Upload PNG, JPG or WebP (max 2 MB). Applies across the shop.</p><img id="logo-preview" class="media-preview" src="${s.logo_key?'/media/logo':''}" alt="Logo preview" ${s.logo_key?'':'hidden'}><input type="file" id="logo-file" accept="image/png,image/jpeg,image/webp"><button class="btn" id="logo-upload">Upload / Change Logo</button><button class="sm red" id="logo-remove">Remove Logo</button></div>
  <div class="panel spaced"><h3>Website Background</h3><p class="muted">Upload PNG, JPG or WebP (max 2 MB). Applies automatically to all shop pages.</p><img id="bg-preview" class="media-preview wide-preview" src="${s.background_key?'/media/background':''}" alt="Background preview" ${s.background_key?'':'hidden'}><input type="file" id="bg-file" accept="image/png,image/jpeg,image/webp"><button class="btn" id="bg-upload">Upload / Change Background</button><button class="sm red" id="bg-remove">Remove Background</button></div>
  <div class="panel spaced"><h3>Store settings</h3><p class="muted">UPI ID shown at payment (optional)</p><input id="su" value="${esc(s.upi_id||'')}" maxlength="100"><p class="muted">Legacy banner text</p><input id="sb" value="${esc(s.banner||'')}" maxlength="160"><button class="btn" id="ss">Save settings</button></div>`);
  const upload=async(kind)=>{const file=$('#'+(kind==='logo'?'logo':'bg')+'-file').files[0];if(!file)return toast('Choose an image first');if(file.size>2*1024*1024)return toast('Image must be 2 MB or smaller');const dataUrl=await new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(r.result);r.onerror=reject;r.readAsDataURL(file)});await api('media','POST',{kind,dataUrl});toast(kind==='logo'?'Logo updated':'Background updated');go('settings')};
  $('#logo-upload').onclick=run(()=>upload('logo'));$('#bg-upload').onclick=run(()=>upload('background'));
  $('#logo-remove').onclick=run(async()=>{if(confirm('Remove website logo?')){await api('media?kind=logo','DELETE');toast('Logo removed');go('settings')}});
  $('#bg-remove').onclick=run(async()=>{if(confirm('Remove website background?')){await api('media?kind=background','DELETE');toast('Background removed');go('settings')}});
  $('#ss').onclick=run(async()=>{await api('settings','PUT',{upi_id:$('#su').value,banner:$('#sb').value});toast('Settings saved')})},
async music(){const m=await api('music');
  const MAXMB=15,EXTS=['mp3','m4a','aac','wav','ogg','oga'],fmtSize=n=>n>=1048576?(n/1048576).toFixed(1)+' MB':Math.max(1,Math.round(n/1024))+' KB';
  if(musicPreviewUrl){URL.revokeObjectURL(musicPreviewUrl);musicPreviewUrl=''}
  let want=m.enabled;
  set(`<h2>Music Settings</h2>
  <div class="panel"><h3>Background music <span id="mu-state" class="mu-state ${m.enabled?'on':'off'}">${m.enabled?'ON':'OFF'}</span></h3>
  <p class="muted">When ON, the track plays automatically and loops forever for every shop visitor. Visitors get no music controls. Some browsers wait for the visitor's first tap or click before sound can start.</p>
  <div class="seg" id="mu-seg" role="group" aria-label="Background music"><button type="button" data-en="1" class="${m.enabled?'on':''}">Enable Music</button><button type="button" data-en="0" class="${m.enabled?'':'on'}">Disable Music</button></div></div>
  <div class="panel spaced"><h3>Current Music</h3>${m.hasFile?`<p class="mu-file"><b>${esc(m.name)}</b><br><span class="muted">${esc({'audio/mpeg':'MP3','audio/mp4':'M4A','audio/aac':'AAC','audio/wav':'WAV','audio/ogg':'OGG'}[m.type]||'AUDIO')} · ${fmtSize(m.size)}${m.updatedAt?' · uploaded '+esc(new Date(m.updatedAt).toLocaleString()):''}</span></p><span class="muted">Music Preview (plays only here, not on the shop)</span><audio class="mu-player" id="mu-current" controls preload="none" src="/api/admin/music/file?v=${encodeURIComponent(m.version)}"></audio>`:'<p class="muted">No music uploaded yet.</p>'}</div>
  <div class="panel spaced"><h3>Change Music</h3><p class="muted">Upload MP3, M4A/AAC, WAV or OGG (max ${MAXMB} MB). MP3 is recommended because it plays on every phone and browser. The new file replaces the current one when you press Save Settings.</p>
  <input type="file" id="mu-file" accept="audio/mpeg,audio/mp4,audio/aac,audio/wav,audio/ogg,.mp3,.m4a,.aac,.wav,.ogg,.oga">
  <div id="mu-sel" hidden><p class="mu-file">Selected: <b id="mu-selname"></b> <span class="muted" id="mu-selmeta"></span></p><span class="muted">Preview before saving</span><audio class="mu-player" id="mu-selplayer" controls preload="metadata"></audio></div></div>
  <div class="spaced"><button class="btn" id="mu-save">Save Settings</button></div>`);
  const seg=$('#mu-seg');
  seg.onclick=e=>{const b=e.target.closest('[data-en]');if(!b)return;want=b.dataset.en==='1';seg.querySelectorAll('[data-en]').forEach(x=>x.classList.toggle('on',x===b))};
  const fileIn=$('#mu-file'),sel=$('#mu-sel'),player=$('#mu-selplayer');
  const bad=f=>{const ext=(f.name.split('.').pop()||'').toLowerCase();if(!EXTS.includes(ext))return'Choose an MP3, M4A, AAC, WAV or OGG file.';if(f.size>MAXMB*1048576)return`File is ${fmtSize(f.size)}. The limit is ${MAXMB} MB.`;if(!f.size)return'That file is empty.';return''};
  fileIn.onchange=()=>{const f=fileIn.files[0];if(musicPreviewUrl){URL.revokeObjectURL(musicPreviewUrl);musicPreviewUrl=''}player.removeAttribute('src');player.load();
    if(!f){sel.hidden=true;return}
    const err=bad(f);if(err){fileIn.value='';sel.hidden=true;toast(err);return}
    musicPreviewUrl=URL.createObjectURL(f);player.src=musicPreviewUrl;$('#mu-selname').textContent=f.name;$('#mu-selmeta').textContent='· '+fmtSize(f.size);sel.hidden=false};
  $('#mu-save').onclick=async()=>{const btn=$('#mu-save'),f=fileIn.files[0];
    try{
      if(f){const err=bad(f);if(err)throw Error(err)}
      if(want&&!f&&!m.hasFile)throw Error('Upload a music file before enabling background music.');
      if(!f&&want===m.enabled)return toast('No changes to save');
      btn.disabled=true;btn.textContent=f?'Uploading…':'Saving…';
      if(f){const r=await fetch('/api/admin/music/upload',{method:'POST',headers:{'Content-Type':'application/octet-stream','X-VM-Admin':'1','X-File-Name':encodeURIComponent(f.name)},body:f});
        const d=await r.json().catch(()=>({}));if(r.status===401){lock();throw Error('Session expired. Please sign in again.')}if(!r.ok)throw Error(d.error||'Upload failed')}
      await api('music','PUT',{enabled:want});
      toast(want?'Music saved — playing on the shop now':'Music saved — background music is OFF');
    }catch(e){toast(e.message)}
    finally{if(tab==='music')go('music')}}
}

};
document.querySelectorAll('#nav button').forEach(b=>b.onclick=()=>go(b.dataset.tab));
$('#logout').onclick=async()=>{await api('logout','POST').catch(()=>{});lock()};
$('#login-form').onsubmit=async e=>{e.preventDefault();$('#login-msg').textContent='';
  try{await api('login','POST',{password:$('#pw').value});$('#pw').value='';unlock()}catch(err){$('#login-msg').textContent=err.message}};
api('me').then(unlock).catch(()=>{});
