// VOID MC Admin Worker (admin.voidmc.bond). Shares the store's D1 database. Secrets: ADMIN_PASSWORD, SESSION_SECRET.

// Auto-creates all tables on first request (safe to run every time), so no manual SQL step is needed.
const SCHEMA = [
 "CREATE TABLE IF NOT EXISTS orders (id TEXT PRIMARY KEY, customer_name TEXT NOT NULL, location TEXT NOT NULL, phone TEXT NOT NULL, email TEXT NOT NULL, items TEXT NOT NULL, subtotal INTEGER NOT NULL, discount INTEGER NOT NULL, total INTEGER NOT NULL, coupon TEXT, prompt TEXT NOT NULL, code TEXT UNIQUE, status TEXT NOT NULL DEFAULT 'awaiting_payment', created_at TEXT NOT NULL)",
 "CREATE INDEX IF NOT EXISTS idx_orders_created_at ON orders(created_at)",
 "CREATE INDEX IF NOT EXISTS idx_orders_code ON orders(code)",
 "CREATE TABLE IF NOT EXISTS coupons (code TEXT PRIMARY KEY, discount INTEGER NOT NULL CHECK(discount BETWEEN 1 AND 90), active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL)",
 "CREATE TABLE IF NOT EXISTS login_attempts (ip_key TEXT PRIMARY KEY, attempts INTEGER NOT NULL DEFAULT 0, window_start INTEGER NOT NULL, blocked_until INTEGER NOT NULL DEFAULT 0)",
 "CREATE TABLE IF NOT EXISTS ranks (name TEXT PRIMARY KEY, price INTEGER NOT NULL CHECK(price BETWEEN 1 AND 100000), tier TEXT NOT NULL DEFAULT '', description TEXT NOT NULL DEFAULT '', icon TEXT NOT NULL DEFAULT '✦', category TEXT NOT NULL DEFAULT 'Ranks', active INTEGER NOT NULL DEFAULT 1, sort INTEGER NOT NULL DEFAULT 0)",
 "CREATE TABLE IF NOT EXISTS categories (name TEXT PRIMARY KEY, created_at TEXT NOT NULL)",
 "INSERT OR IGNORE INTO categories(name,created_at) VALUES('Ranks',CURRENT_TIMESTAMP)",
 "CREATE TABLE IF NOT EXISTS free_rank_claims (id TEXT PRIMARY KEY,customer_name TEXT NOT NULL,minecraft_username TEXT NOT NULL,location TEXT NOT NULL,phone TEXT NOT NULL,email TEXT NOT NULL,rank_name TEXT NOT NULL DEFAULT 'SEAMAN',created_at TEXT NOT NULL)",
 "CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL)",
 "CREATE TABLE IF NOT EXISTS announcements (id TEXT PRIMARY KEY,message TEXT NOT NULL,active INTEGER NOT NULL DEFAULT 1,created_at TEXT NOT NULL,updated_at TEXT NOT NULL)",
 "INSERT OR IGNORE INTO settings(key,value) VALUES ('logo_key',''),('background_key','')",
 "INSERT OR IGNORE INTO settings (key,value) VALUES ('maintenance_enabled','0'),('maintenance_message','We are performing scheduled maintenance to improve VOID MC SHOP. Please check back soon.'),('maintenance_updated_at','')",
 "INSERT OR IGNORE INTO settings (key,value) VALUES ('music_enabled','0'),('music_key',''),('music_name',''),('music_type',''),('music_size','0'),('music_version',''),('music_updated_at','')",
 "INSERT OR IGNORE INTO settings (key,value) VALUES ('free_rank_name','SEAMAN'),('free_rank_price','79'),('free_rank_max','3'),('free_rank_description','Make waves across the server.'),('free_rank_enabled','1')",
 "INSERT OR IGNORE INTO ranks (name,price,tier,description,icon,sort) SELECT 'BOOSTER',49,'STARTER BOOST','Step into the spotlight.','✦',1 WHERE NOT EXISTS (SELECT 1 FROM ranks)",
 "INSERT OR IGNORE INTO ranks (name,price,tier,description,icon,sort) SELECT 'SEAMAN',79,'OCEAN WARRIOR','Make waves across the server.','⚓',2 WHERE (SELECT COUNT(*) FROM ranks)=1",
 "INSERT OR IGNORE INTO ranks (name,price,tier,description,icon,sort) SELECT 'CAPTAIN',129,'ELITE COMMAND','Lead your own adventure.','♛',3 WHERE (SELECT COUNT(*) FROM ranks)=2",
 "INSERT OR IGNORE INTO ranks (name,price,tier,description,icon,sort) SELECT 'ROYAL',179,'ROYAL STATUS','A crown worthy of legends.','✧',4 WHERE (SELECT COUNT(*) FROM ranks)=3",
 "INSERT OR IGNORE INTO ranks (name,price,tier,description,icon,sort) SELECT 'MONARCH',229,'ULTIMATE POWER','Rule the world of VOID MC.','♨',5 WHERE (SELECT COUNT(*) FROM ranks)=4"
];
let schemaReady;
const ensureSchema = env => schemaReady ||= (async()=>{await env.DB.batch(SCHEMA.map(s=>env.DB.prepare(s)));const cols=(await env.DB.prepare('PRAGMA table_info(ranks)').all()).results||[];if(!cols.some(c=>c.name==='category'))await env.DB.prepare("ALTER TABLE ranks ADD COLUMN category TEXT NOT NULL DEFAULT 'Ranks'").run();const ocols=(await env.DB.prepare('PRAGMA table_info(orders)').all()).results||[];if(!ocols.some(c=>c.name==='minecraft_username'))await env.DB.prepare("ALTER TABLE orders ADD COLUMN minecraft_username TEXT NOT NULL DEFAULT ''").run();const ccols=(await env.DB.prepare('PRAGMA table_info(free_rank_claims)').all()).results||[];if(ccols.length&&!ccols.some(c=>c.name==='status'))await env.DB.prepare("ALTER TABLE free_rank_claims ADD COLUMN status TEXT NOT NULL DEFAULT 'active'").run();})().catch(e=>{schemaReady=null;throw e});
const COOKIE = '__Host-vm_admin', ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const json = (d, s = 200, h = {}) => new Response(JSON.stringify(d), { status: s, headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', ...h } });
const clean = (v, m = 120) => String(v ?? '').trim().slice(0, m);
const now = () => new Date().toISOString();
const hex = b => [...new Uint8Array(b)].map(x => x.toString(16).padStart(2, '0')).join('');
const rnd = n => [...crypto.getRandomValues(new Uint8Array(n))].map(b => ALPHABET[b % 32]).join('');
async function hmac(v, secret) {
  const k = await crypto.subtle.importKey('raw', new TextEncoder().encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  return hex(await crypto.subtle.sign('HMAC', k, new TextEncoder().encode(v)));
}
const eq = (a, b) => { if (a.length !== b.length) return false; let o = 0; for (let i = 0; i < a.length; i++) o |= a.charCodeAt(i) ^ b.charCodeAt(i); return o === 0; };
const body = async r => { try { return await r.json(); } catch { return {}; } };
const pctOk = n => Number.isInteger(n) && n >= 1 && n <= 90;


// ---- Free Rank (settings live in the shared `settings` table; the store Worker reads the same keys)
const FREE_DEFAULTS = { free_rank_name: 'SEAMAN', free_rank_price: '79', free_rank_max: '3', free_rank_description: 'Make waves across the server.', free_rank_enabled: '1' };
async function freeRankState(DB) {
  const { results = [] } = await DB.prepare("SELECT key,value FROM settings WHERE key IN ('free_rank_name','free_rank_price','free_rank_max','free_rank_description','free_rank_enabled')").all();
  const m = { ...FREE_DEFAULTS, ...Object.fromEntries(results.map(r => [r.key, r.value])) };
  const claimed = Number((await DB.prepare("SELECT COUNT(*) n FROM free_rank_claims WHERE status='active'").first()).n || 0);
  const maxN = Number(m.free_rank_max), max = Number.isInteger(maxN) && maxN >= 0 ? maxN : 3, priceN = Number(m.free_rank_price);
  return { name: m.free_rank_name, price: Number.isInteger(priceN) && priceN >= 0 ? priceN : 0, description: m.free_rank_description, max, enabled: m.free_rank_enabled === '1', claimed, remaining: Math.max(0, max - claimed) };
}

// ---- Maintenance Mode (shared `settings` table; the store Worker reads the same keys live on every request)
const MAINT_DEFAULT_MSG = 'We are performing scheduled maintenance to improve VOID MC SHOP. Please check back soon.';
async function maintenanceState(DB) {
  const { results = [] } = await DB.prepare("SELECT key,value FROM settings WHERE key IN ('maintenance_enabled','maintenance_message','maintenance_updated_at')").all();
  const m = Object.fromEntries(results.map(r => [r.key, r.value]));
  return { enabled: m.maintenance_enabled === '1', message: clean(m.maintenance_message, 500) || MAINT_DEFAULT_MSG, updatedAt: m.maintenance_updated_at || '' };
}

async function isAdmin(request, env) {
  const raw = (request.headers.get('Cookie') || '').split(';').map(x => x.trim()).find(x => x.startsWith(COOKIE + '='))?.slice(COOKIE.length + 1);
  const [t, exp, sig] = (raw || '').split('.');
  if (!t || !/^\d+$/.test(exp || '') || !sig || Number(exp) < Date.now() / 1000) return false;
  return eq(sig, await hmac(`${t}.${exp}`, env.SESSION_SECRET));
}

// ---- Background music. Flags live in the shared `settings` table, the audio file in the shared R2 bucket (MEDIA);
// the shop Worker reads the same keys and streams the file to visitors.
const MUSIC_MAX = 15 * 1024 * 1024;   // 15 MB: big enough for a full track, small enough to stay fast on mobile data
const MUSIC_FORMATS = {               // what the file CONTENT is -> the content type we serve + the extensions we accept for it
  mp3: { type: 'audio/mpeg', label: 'MP3', ext: ['mp3'] },
  aac: { type: 'audio/aac', label: 'AAC', ext: ['aac'] },
  m4a: { type: 'audio/mp4', label: 'M4A', ext: ['m4a', 'mp4', 'aac'] },
  wav: { type: 'audio/wav', label: 'WAV', ext: ['wav', 'wave'] },
  ogg: { type: 'audio/ogg', label: 'OGG', ext: ['ogg', 'oga', 'opus'] }
};
// One MPEG audio / ADTS frame header at offset i? Returns 'mp3' | 'aac' | ''.
function mpegFrame(b, i) {
  if (i + 3 >= b.length || b[i] !== 0xFF || (b[i + 1] & 0xE0) !== 0xE0) return '';
  const ver = (b[i + 1] >> 3) & 3, layer = (b[i + 1] >> 1) & 3, br = (b[i + 2] >> 4) & 15, sr = (b[i + 2] >> 2) & 3;
  if (layer === 0) return (b[i + 1] & 0xF6) === 0xF0 && ((b[i + 2] >> 2) & 15) <= 12 ? 'aac' : '';   // ADTS AAC
  return ver === 1 || br === 15 || sr === 3 ? '' : 'mp3';
}
// Identify the audio format from the file's own bytes (the browser-supplied type and the file name are never trusted).
function sniffAudio(b) {
  if (b.length < 16) return '';
  const s = (o, n) => String.fromCharCode(...b.subarray(o, o + n));
  if (s(0, 4) === 'OggS') return 'ogg';
  if (s(0, 4) === 'RIFF' && s(8, 4) === 'WAVE') return 'wav';
  if (s(4, 4) === 'ftyp' && ['M4A ', 'M4B ', 'mp42', 'mp41', 'isom', 'iso2'].includes(s(8, 4))) return 'm4a';
  if (s(0, 3) === 'ID3') {   // ID3v2 tag first: the first real audio frame must follow it
    const start = 10 + (((b[6] & 127) << 21) | ((b[7] & 127) << 14) | ((b[8] & 127) << 7) | (b[9] & 127)) + ((b[5] & 16) ? 10 : 0);
    for (let i = start; i <= Math.min(b.length - 4, start + 4096); i++) { const f = mpegFrame(b, i); if (f) return f; }
    return '';
  }
  return mpegFrame(b, 0);
}
// Read the request body but give up as soon as it exceeds `max` bytes (a Content-Length header can lie).
async function readCapped(request, max) {
  if (Number(request.headers.get('content-length') || 0) > max) return null;
  if (!request.body) return new Uint8Array(0);
  const reader = request.body.getReader(), chunks = [];
  let total = 0;
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    total += value.byteLength;
    if (total > max) { await reader.cancel().catch(() => {}); return null; }
    chunks.push(value);
  }
  const out = new Uint8Array(total);
  let o = 0; for (const c of chunks) { out.set(c, o); o += c.byteLength; }
  return out;
}
async function musicState(DB) {
  const { results = [] } = await DB.prepare("SELECT key,value FROM settings WHERE key LIKE 'music\\_%' ESCAPE '\\'").all();
  const m = Object.fromEntries(results.map(r => [r.key, r.value]));
  return { enabled: m.music_enabled === '1' && !!m.music_key, hasFile: !!m.music_key, name: m.music_name || '', type: m.music_type || '', size: Number(m.music_size) || 0, version: m.music_version || '', updatedAt: m.music_updated_at || '' };
}
const upsert = (DB, k, v) => DB.prepare('INSERT INTO settings (key,value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value').bind(k, String(v));
function contentRange(r, size) {
  if (!r) return null;
  let start, end;
  if (r.suffix !== undefined) { start = Math.max(0, size - r.suffix); end = size - 1; }
  else { start = r.offset ?? 0; end = r.length !== undefined ? Math.min(size - 1, start + r.length - 1) : size - 1; }
  return `bytes ${start}-${end}/${size}`;
}

async function api(request, env) {
  const url = new URL(request.url), path = url.pathname, method = request.method, DB = env.DB;
  if (!DB || !env.ADMIN_PASSWORD || !env.SESSION_SECRET) return json({ error: 'Admin backend not configured (D1 binding / secrets).' }, 500);
  await ensureSchema(env);
  if (method !== 'GET') { // CSRF defence on top of SameSite=Strict
    const o = request.headers.get('origin');
    if ((o && o !== url.origin) || request.headers.get('x-vm-admin') !== '1') return json({ error: 'Forbidden' }, 403);
  }

  if (path === '/api/admin/login' && method === 'POST') {
    const key = await hmac(request.headers.get('CF-Connecting-IP') || 'unknown', env.SESSION_SECRET), t = Date.now();
    const a = await DB.prepare('SELECT window_start,blocked_until FROM login_attempts WHERE ip_key=?').bind(key).first();
    if (a?.blocked_until > t) return json({ error: 'Too many attempts. Try again in 15 minutes.' }, 429);
    if (!a || t - a.window_start > 900000) await DB.prepare('INSERT INTO login_attempts (ip_key,attempts,window_start,blocked_until) VALUES (?,0,?,0) ON CONFLICT(ip_key) DO UPDATE SET attempts=0,window_start=excluded.window_start,blocked_until=0').bind(key, t).run();
    const pw = String((await body(request)).password || '');
    // compare HMACs so length/timing of the real password never leaks
    if (!eq(await hmac(pw, env.SESSION_SECRET), await hmac(String(env.ADMIN_PASSWORD), env.SESSION_SECRET))) {
      const u = await DB.prepare('UPDATE login_attempts SET attempts=attempts+1 WHERE ip_key=? RETURNING attempts').bind(key).first();
      if (u?.attempts >= 5) await DB.prepare('UPDATE login_attempts SET blocked_until=? WHERE ip_key=?').bind(t + 900000, key).run();
      return json({ error: 'Invalid credentials' }, 401);
    }
    await DB.prepare('DELETE FROM login_attempts WHERE ip_key=?').bind(key).run();
    const payload = `${rnd(32)}.${Math.floor(t / 1000) + 8 * 3600}`;
    return json({ ok: true }, 200, { 'set-cookie': `${COOKIE}=${payload}.${await hmac(payload, env.SESSION_SECRET)}; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=28800` });
  }
  if (path === '/api/admin/logout' && method === 'POST') return json({ ok: true }, 200, { 'set-cookie': `${COOKIE}=; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=0` });
  if (!await isAdmin(request, env)) return json({ error: 'Admin login required' }, 401);

  if (path === '/api/admin/me') return json({ ok: true });
  if (path === '/api/admin/maintenance' && method === 'GET') return json(await maintenanceState(DB));
  if (path === '/api/admin/maintenance' && method === 'PUT') {
    const d = await body(request), cur = await maintenanceState(DB);
    if (d.enabled !== undefined && typeof d.enabled !== 'boolean') return json({ error: 'Enabled must be true or false.' }, 400);
    if (d.message !== undefined && typeof d.message !== 'string') return json({ error: 'Message must be text.' }, 400);
    const message = d.message === undefined ? cur.message : clean(d.message, 500);
    if (!message) return json({ error: 'Enter a maintenance reason/message.' }, 400);
    const enabled = d.enabled === undefined ? cur.enabled : d.enabled;
    await DB.batch([['maintenance_enabled', enabled ? '1' : '0'], ['maintenance_message', message], ['maintenance_updated_at', now()]]
      .map(([k, v]) => DB.prepare('INSERT INTO settings (key,value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value').bind(k, v)));
    return json({ ok: true, ...(await maintenanceState(DB)) });
  }
  if (path === '/api/admin/stats') {
    const { results = [] } = await DB.prepare('SELECT status,COUNT(*) n,COALESCE(SUM(total),0) s FROM orders GROUP BY status').all();
    const c = await DB.prepare('SELECT COUNT(*) n FROM coupons WHERE active=1').first();
    return json({ byStatus: results, activeCoupons: c.n, maintenance: (await maintenanceState(DB)).enabled });
  }
  if (path === '/api/admin/orders' && method === 'GET') {
    const { results = [] } = await DB.prepare('SELECT id,customer_name,location,phone,minecraft_username,email,items,subtotal,discount,total,coupon,code,status,created_at FROM orders ORDER BY created_at DESC LIMIT 300').all();
    return json(results.map(x => ({ ...x, items: JSON.parse(x.items) })));
  }
  let m = path.match(/^\/api\/admin\/orders\/([A-Za-z0-9-]+)$/);
  if(m && method==='DELETE'){const r=await DB.prepare('DELETE FROM orders WHERE id=?').bind(m[1]).run();return r.meta.changes?json({ok:true}):json({error:'Order not found'},404);}
  if (path === '/api/admin/free-claims' && method === 'GET') {const {results=[]}=await DB.prepare('SELECT * FROM free_rank_claims ORDER BY created_at ASC').all();return json(results);}
  m = path.match(/^\/api\/admin\/free-claims\/([A-Za-z0-9-]+)$/);
  if (m && method === 'DELETE') { const r = await DB.prepare("UPDATE free_rank_claims SET status='cancelled' WHERE id=? AND status='active'").bind(m[1]).run(); return r.meta.changes ? json({ ok: true }) : json({ error: 'Active claim not found' }, 404); }
  if (path === '/api/admin/free-rank' && method === 'GET') return json({ ...(await freeRankState(DB)), claims: (await DB.prepare('SELECT id,customer_name,minecraft_username,location,phone,email,rank_name,created_at,status FROM free_rank_claims ORDER BY created_at ASC').all()).results || [] });
  if (path === '/api/admin/free-rank' && method === 'PUT') {
    const d = await body(request), name = clean(d.name, 24), description = clean(d.description, 120), price = Number(d.price), max = Number(d.max);
    if (!/^[A-Za-z0-9 _-]{2,24}$/.test(name)) return json({ error: 'Rank name: 2–24 letters, numbers, spaces, - or _.' }, 400);
    if (!Number.isInteger(price) || price < 0 || price > 100000) return json({ error: 'Price must be a whole number of rupees, 0–100000.' }, 400);
    if (!Number.isInteger(max) || max < 0 || max > 1000) return json({ error: 'Maximum claims must be a whole number, 0–1000.' }, 400);
    if (typeof d.enabled !== 'boolean') return json({ error: 'Enabled must be ON or OFF.' }, 400);
    await DB.batch([['free_rank_name', name], ['free_rank_price', String(price)], ['free_rank_max', String(max)], ['free_rank_description', description], ['free_rank_enabled', d.enabled ? '1' : '0']]
      .map(([k, v]) => DB.prepare('INSERT INTO settings (key,value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value').bind(k, v)));
    return json({ ok: true, ...(await freeRankState(DB)) });
  }
  if (path === '/api/admin/verify' && method === 'POST') {
    const code = clean((await body(request)).code, 20).toUpperCase();
    if (!/^VM[A-Z2-9]{16}HE$/.test(code)) return json({ valid: false });
    const r = await DB.prepare('SELECT id,customer_name,location,phone,minecraft_username,email,items,total,coupon,status,created_at FROM orders WHERE code=?').bind(code).first();
    return json(r ? { valid: true, ...r, items: JSON.parse(r.items) } : { valid: false });
  }
  m = path.match(/^\/api\/admin\/orders\/([A-Za-z0-9-]+)\/status$/);
  if (m && method === 'POST') {
    const s = clean((await body(request)).status, 20);
    if (!['verified', 'rejected', 'payment_submitted'].includes(s)) return json({ error: 'Invalid status' }, 400);
    const r = await DB.prepare('UPDATE orders SET status=? WHERE id=? AND code IS NOT NULL').bind(s, m[1]).run();
    return r.meta.changes ? json({ ok: true }) : json({ error: 'Order has no payment code yet' }, 404);
  }

  // ---- coupons
  if (path === '/api/admin/coupons' && method === 'GET') return json((await DB.prepare('SELECT code,discount,active,created_at FROM coupons ORDER BY created_at DESC').all()).results);
  if (path === '/api/admin/coupons' && method === 'POST') {
    const d = await body(request), code = clean(d.code, 6).toUpperCase(), pct = Number(d.discount);
    if (!/^[A-Z0-9]{6}$/.test(code) || !pctOk(pct)) return json({ error: 'Code must be exactly 6 letters/numbers; discount 1–90%.' }, 400);
    try { await DB.prepare('INSERT INTO coupons (code,discount,created_at) VALUES (?,?,?)').bind(code, pct, now()).run(); } catch { return json({ error: 'That coupon already exists.' }, 409); }
    return json({ ok: true, code, discount: pct });
  }
  if (path === '/api/admin/coupons/random' && method === 'POST') {
    const pct = Number((await body(request)).discount);
    if (!pctOk(pct)) return json({ error: 'Enter a discount between 1 and 90.' }, 400);
    for (let i = 0; i < 20; i++) { const code = rnd(6); try { await DB.prepare('INSERT INTO coupons (code,discount,created_at) VALUES (?,?,?)').bind(code, pct, now()).run(); return json({ ok: true, code, discount: pct }); } catch {} }
    return json({ error: 'Could not generate a unique coupon.' }, 500);
  }
  m = path.match(/^\/api\/admin\/coupons\/([A-Za-z0-9]{6})$/);
  if (m && method === 'PATCH') { const r = await DB.prepare('UPDATE coupons SET active=? WHERE code=?').bind((await body(request)).active ? 1 : 0, m[1].toUpperCase()).run(); return r.meta.changes ? json({ ok: true }) : json({ error: 'Not found' }, 404); }
  if (m && method === 'DELETE') { await DB.prepare('DELETE FROM coupons WHERE code=?').bind(m[1].toUpperCase()).run(); return json({ ok: true }); }

  if(path==='/api/admin/categories'&&method==='GET')return json((await DB.prepare('SELECT * FROM categories ORDER BY name').all()).results);
  if(path==='/api/admin/categories'&&method==='POST'){const name=clean((await body(request)).name,30);if(!/^[A-Za-z0-9 _-]{2,30}$/.test(name))return json({error:'Category name must be 2–30 letters/numbers.'},400);try{await DB.prepare('INSERT INTO categories(name,created_at) VALUES(?,?)').bind(name,now()).run()}catch{return json({error:'Category already exists.'},409)}return json({ok:true})}
  // ---- ranks (what the store sells)
  if (path === '/api/admin/ranks' && method === 'GET') return json((await DB.prepare('SELECT * FROM ranks ORDER BY category,sort,name').all()).results);
  const rankFields = d => ({ price: Number(d.price), tier: clean(d.tier, 30), description: clean(d.description, 80), icon: clean(d.icon, 4) || '✦', category: clean(d.category,30) || 'Ranks', active: d.active === false ? 0 : 1, sort: Number.isInteger(Number(d.sort)) ? Number(d.sort) : 0 });
  if (path === '/api/admin/ranks' && method === 'POST') {
    const d = await body(request), name = clean(d.name, 16).toUpperCase(), f = rankFields(d);
    if (!/^[A-Z0-9]{3,16}$/.test(name) || !Number.isInteger(f.price) || f.price < 1 || f.price > 100000) return json({ error: 'Name: 3–16 letters/numbers. Price: whole rupees 1–100000.' }, 400);
    try { await DB.prepare('INSERT INTO ranks (name,price,tier,description,icon,category,active,sort) VALUES (?,?,?,?,?,?,?,?)').bind(name, f.price, f.tier, f.description, f.icon, f.category, f.active, f.sort).run(); } catch { return json({ error: 'Rank already exists.' }, 409); }
    return json({ ok: true });
  }
  m = path.match(/^\/api\/admin\/ranks\/([A-Z0-9]{3,16})$/);
  if (m && method === 'PUT') {
    const f = rankFields(await body(request));
    if (!Number.isInteger(f.price) || f.price < 1 || f.price > 100000) return json({ error: 'Price must be whole rupees 1–100000.' }, 400);
    const r = await DB.prepare('UPDATE ranks SET price=?,tier=?,description=?,icon=?,category=?,active=?,sort=? WHERE name=?').bind(f.price, f.tier, f.description, f.icon, f.category, f.active, f.sort, m[1]).run();
    return r.meta.changes ? json({ ok: true }) : json({ error: 'Not found' }, 404);
  }
  if (m && method === 'DELETE') { await DB.prepare('DELETE FROM ranks WHERE name=?').bind(m[1]).run(); return json({ ok: true }); }

  // ---- Background music (admin only; every route below sits behind isAdmin + the CSRF header/Origin check)
  if (path === '/api/admin/music' && method === 'GET') return json(await musicState(DB));
  if (path === '/api/admin/music' && method === 'PUT') {
    const d = await body(request), cur = await musicState(DB);
    if (typeof d.enabled !== 'boolean') return json({ error: 'Enabled must be true or false.' }, 400);
    if (d.enabled && !cur.hasFile) return json({ error: 'Upload a music file before enabling background music.' }, 400);
    await upsert(DB, 'music_enabled', d.enabled ? '1' : '0').run();
    return json({ ok: true, ...(await musicState(DB)) });
  }
  if (path === '/api/admin/music/upload' && method === 'POST') {
    if (!env.MEDIA) return json({ error: 'R2 MEDIA bucket binding is missing.' }, 503);
    const bytes = await readCapped(request, MUSIC_MAX);
    if (!bytes) return json({ error: `Audio file must be ${MUSIC_MAX / 1048576} MB or smaller.` }, 413);
    if (!bytes.length) return json({ error: 'Choose an audio file first.' }, 400);
    let name = ''; try { name = decodeURIComponent(request.headers.get('x-file-name') || ''); } catch { /* bad encoding: fall back to default name */ }
    name = name.split(/[\\/]/).pop().replace(/[^\p{L}\p{N} ._()\[\]-]/gu, '_').trim().slice(0, 100) || 'music';
    const ext = ((name.match(/\.([A-Za-z0-9]+)$/) || [])[1] || '').toLowerCase(), kind = sniffAudio(bytes);
    if (!kind) return json({ error: 'That file is not a valid MP3, M4A/AAC, WAV or OGG audio file.' }, 400);
    if (!MUSIC_FORMATS[kind].ext.includes(ext)) return json({ error: `The file extension does not match its contents (detected: ${MUSIC_FORMATS[kind].label}).` }, 400);
    const fmt = MUSIC_FORMATS[kind], t = Date.now(), key = `voidmc/music/${t}-${hex(crypto.getRandomValues(new Uint8Array(8)))}`;
    const old = (await DB.prepare("SELECT value FROM settings WHERE key='music_key'").first())?.value || '';
    await env.MEDIA.put(key, bytes, { httpMetadata: { contentType: fmt.type } });
    try {
      await DB.batch([['music_key', key], ['music_name', name], ['music_type', fmt.type], ['music_size', bytes.length], ['music_version', t], ['music_updated_at', now()]].map(([k, v]) => upsert(DB, k, v)));
    } catch (e) { await env.MEDIA.delete(key).catch(() => {}); throw e; }   // never leave an orphan file behind
    if (old && old !== key) await env.MEDIA.delete(old).catch(() => {});      // the new track replaces the previous one
    return json({ ok: true, ...(await musicState(DB)) });
  }
  if (path === '/api/admin/music/file' && method === 'GET') {   // admin preview of the saved track (works even while music is OFF)
    const row = await DB.prepare("SELECT value FROM settings WHERE key='music_key'").first();
    if (!row?.value || !env.MEDIA) return json({ error: 'No music uploaded yet.' }, 404);
    const type = (await DB.prepare("SELECT value FROM settings WHERE key='music_type'").first())?.value || 'audio/mpeg';
    let obj;
    try { obj = await env.MEDIA.get(row.value, { range: request.headers, onlyIf: request.headers }); }
    catch (e) { if (/range/i.test(String(e && e.message))) return new Response('Range not satisfiable', { status: 416 }); throw e; }
    if (!obj) return json({ error: 'Music file is missing from storage.' }, 404);
    const cr = contentRange(obj.range, obj.size);
    return new Response(obj.body || null, { status: !obj.body ? 304 : cr ? 206 : 200, headers: { 'content-type': type, 'accept-ranges': 'bytes', 'x-content-type-options': 'nosniff', 'cache-control': 'private, no-cache', etag: obj.httpEtag, ...(cr ? { 'content-range': cr } : {}) } });
  }
  // ---- Live announcements
  if(path==='/api/admin/announcements' && method==='GET') return json((await DB.prepare('SELECT * FROM announcements ORDER BY updated_at DESC').all()).results||[]);
  if(path==='/api/admin/announcements' && method==='POST') {const d=await body(request),message=clean(d.message,240);if(!message)return json({error:'Announcement cannot be empty.'},400);const id='ANN-'+hex(crypto.getRandomValues(new Uint8Array(6))).toUpperCase(),t=now();await DB.prepare('INSERT INTO announcements(id,message,active,created_at,updated_at) VALUES(?,?,?,?,?)').bind(id,message,d.active===false?0:1,t,t).run();return json({ok:true,id});}
  let am=path.match(/^\/api\/admin\/announcements\/([A-Za-z0-9-]+)$/);
  if(am && method==='PUT'){const d=await body(request),message=clean(d.message,240);if(!message)return json({error:'Announcement cannot be empty.'},400);const r=await DB.prepare('UPDATE announcements SET message=?,active=?,updated_at=? WHERE id=?').bind(message,d.active===false?0:1,now(),am[1]).run();return r.meta.changes?json({ok:true}):json({error:'Announcement not found'},404);}
  if(am && method==='DELETE'){const r=await DB.prepare('DELETE FROM announcements WHERE id=?').bind(am[1]).run();return r.meta.changes?json({ok:true}):json({error:'Announcement not found'},404);}
  // ---- V3.0.0 announcement + R2 media management
  if (path === '/api/admin/media' && method === 'POST') {
    if (!env.MEDIA) return json({error:'R2 MEDIA bucket binding is missing.'},503);
    const d=await body(request), kind=d.kind==='logo'?'logo':d.kind==='background'?'background':'';
    if(!kind || typeof d.dataUrl!=='string') return json({error:'Choose a logo or background image.'},400);
    const match=d.dataUrl.match(/^data:(image\/(?:png|jpeg|webp));base64,([A-Za-z0-9+/=]+)$/);if(!match)return json({error:'Only PNG, JPG and WebP images are allowed.'},400);
    const bytes=Uint8Array.from(atob(match[2]),c=>c.charCodeAt(0));if(bytes.length>2*1024*1024)return json({error:'Image must be 2 MB or smaller.'},413);
    const isPng=bytes.length>8&&[137,80,78,71,13,10,26,10].every((v,i)=>bytes[i]===v),isJpg=bytes.length>3&&bytes[0]===255&&bytes[1]===216&&bytes[2]===255,isWebp=bytes.length>12&&String.fromCharCode(...bytes.slice(0,4))==='RIFF'&&String.fromCharCode(...bytes.slice(8,12))==='WEBP';if(!(isPng||isJpg||isWebp))return json({error:'The uploaded file is not a valid PNG, JPG or WebP image.'},400);
    const old=await DB.prepare('SELECT value FROM settings WHERE key=?').bind(`${kind}_key`).first();const key=`voidmc/${kind}/${Date.now()}-${hex(crypto.getRandomValues(new Uint8Array(8)))}`;await env.MEDIA.put(key,bytes,{httpMetadata:{contentType:match[1]}});
    await DB.prepare('INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value').bind(`${kind}_key`,key).run();if(old?.value)await env.MEDIA.delete(old.value);return json({ok:true,key});
  }
  if (path === '/api/admin/media' && method === 'DELETE') {
    const kind=new URL(request.url).searchParams.get('kind');if(!['logo','background'].includes(kind))return json({error:'Invalid image type.'},400);
    const row=await DB.prepare('SELECT value FROM settings WHERE key=?').bind(`${kind}_key`).first();if(row?.value&&env.MEDIA)await env.MEDIA.delete(row.value);
    await DB.prepare("INSERT INTO settings(key,value) VALUES(?,'') ON CONFLICT(key) DO UPDATE SET value=''").bind(`${kind}_key`).run();return json({ok:true});
  }
  // ---- store settings
  if (path === '/api/admin/settings' && method === 'GET') {
    const { results = [] } = await DB.prepare("SELECT key,value FROM settings WHERE key IN ('upi_id','banner','logo_key','background_key')").all();
    return json(Object.fromEntries(results.map(r => [r.key, r.value])));
  }
  if (path === '/api/admin/settings' && method === 'PUT') {
    const d = await body(request);
    for (const [k, v, max] of [['upi_id', d.upi_id, 100], ['banner', d.banner, 160]])
      await DB.prepare('INSERT INTO settings (key,value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value').bind(k, clean(v, max)).run();
    return json({ ok: true });
  }
  return json({ error: 'Not found' }, 404);
}

export default {
  async fetch(request, env) {
    const url=new URL(request.url);
    if (url.pathname === '/media/logo' || url.pathname === '/media/background') { try {const kind=url.pathname.endsWith('/logo')?'logo':'background';const row=await env.DB.prepare('SELECT value FROM settings WHERE key=?').bind(`${kind}_key`).first();if(!row?.value||!env.MEDIA)return new Response('Not found',{status:404});const obj=await env.MEDIA.get(row.value);if(!obj)return new Response('Not found',{status:404});const h=new Headers();obj.writeHttpMetadata(h);h.set('cache-control','public,max-age=300');return new Response(obj.body,{headers:h})}catch{return new Response('Not found',{status:404})}}
    if (url.pathname.startsWith('/api/')) {
      try { return await api(request, env); } catch (e) { console.error(e); return json({ error: 'Server error' }, 500); }
    }
    return env.ASSETS.fetch(request);
  }
};
