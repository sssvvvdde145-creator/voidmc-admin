// VOID MC Admin Worker (admin.voidmc.bond). Shares the store's D1 database. Secrets: ADMIN_PASSWORD, SESSION_SECRET.

// Auto-creates all tables on first request (safe to run every time), so no manual SQL step is needed.
const SCHEMA = [
 "CREATE TABLE IF NOT EXISTS orders (id TEXT PRIMARY KEY, customer_name TEXT NOT NULL, location TEXT NOT NULL, phone TEXT NOT NULL, email TEXT NOT NULL, items TEXT NOT NULL, subtotal INTEGER NOT NULL, discount INTEGER NOT NULL, total INTEGER NOT NULL, coupon TEXT, prompt TEXT NOT NULL, code TEXT UNIQUE, status TEXT NOT NULL DEFAULT 'awaiting_payment', created_at TEXT NOT NULL)",
 "CREATE INDEX IF NOT EXISTS idx_orders_created_at ON orders(created_at)",
 "CREATE INDEX IF NOT EXISTS idx_orders_code ON orders(code)",
 "CREATE TABLE IF NOT EXISTS coupons (code TEXT PRIMARY KEY, discount INTEGER NOT NULL CHECK(discount BETWEEN 1 AND 90), active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL)",
 "CREATE TABLE IF NOT EXISTS login_attempts (ip_key TEXT PRIMARY KEY, attempts INTEGER NOT NULL DEFAULT 0, window_start INTEGER NOT NULL, blocked_until INTEGER NOT NULL DEFAULT 0)",
 "CREATE TABLE IF NOT EXISTS ranks (name TEXT PRIMARY KEY, price INTEGER NOT NULL CHECK(price BETWEEN 1 AND 100000), tier TEXT NOT NULL DEFAULT '', description TEXT NOT NULL DEFAULT '', icon TEXT NOT NULL DEFAULT '✦', active INTEGER NOT NULL DEFAULT 1, sort INTEGER NOT NULL DEFAULT 0)",
 "CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL)",
 "INSERT OR IGNORE INTO ranks (name,price,tier,description,icon,sort) SELECT 'BOOSTER',49,'STARTER BOOST','Step into the spotlight.','✦',1 WHERE NOT EXISTS (SELECT 1 FROM ranks)",
 "INSERT OR IGNORE INTO ranks (name,price,tier,description,icon,sort) SELECT 'SEAMAN',79,'OCEAN WARRIOR','Make waves across the server.','⚓',2 WHERE (SELECT COUNT(*) FROM ranks)=1",
 "INSERT OR IGNORE INTO ranks (name,price,tier,description,icon,sort) SELECT 'CAPTAIN',129,'ELITE COMMAND','Lead your own adventure.','♛',3 WHERE (SELECT COUNT(*) FROM ranks)=2",
 "INSERT OR IGNORE INTO ranks (name,price,tier,description,icon,sort) SELECT 'ROYAL',179,'ROYAL STATUS','A crown worthy of legends.','✧',4 WHERE (SELECT COUNT(*) FROM ranks)=3",
 "INSERT OR IGNORE INTO ranks (name,price,tier,description,icon,sort) SELECT 'MONARCH',229,'ULTIMATE POWER','Rule the world of VOID MC.','♨',5 WHERE (SELECT COUNT(*) FROM ranks)=4"
];
let schemaReady;
const ensureSchema = env => schemaReady ||= env.DB.batch(SCHEMA.map(s => env.DB.prepare(s))).catch(e => { schemaReady = null; throw e; });
const COOKIE = '__Host-vm_admin', ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const json = (d, s = 200, h = {}) => new Response(JSON.stringify(d), { status: s, headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', ...h } });
const clean = (v, m = 120) => String(v ?? '').trim().slice(0, m);
const now = () => new Date().toISOString();
const hex = b => [...new Uint8Array(b)].map(x => x.toString(16).padStart(2, '0')).join('');
const rnd = n => [...crypto.getRandomValues(new Uint8Array(n))].map(b => ALPHABET[b % 32]).join('');
async function hmac(v, secret) {
  const k = await crypto.subtle.importKey('raw', new TextEncoder().encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  return hex(await crypto.subtle.sign('HMAC', k, new TextEncoder().encode(v)));
}
const eq = (a, b) => { if (a.length !== b.length) return false; let o = 0; for (let i = 0; i < a.length; i++) o |= a.charCodeAt(i) ^ b.charCodeAt(i); return o === 0; };
const body = async r => { try { return await r.json(); } catch { return {}; } };
const pctOk = n => Number.isInteger(n) && n >= 1 && n <= 90;

async function isAdmin(request, env) {
  const raw = (request.headers.get('Cookie') || '').split(';').map(x => x.trim()).find(x => x.startsWith(COOKIE + '='))?.slice(COOKIE.length + 1);
  const [t, exp, sig] = (raw || '').split('.');
  if (!t || !/^\d+$/.test(exp || '') || !sig || Number(exp) < Date.now() / 1000) return false;
  return eq(sig, await hmac(`${t}.${exp}`, env.SESSION_SECRET));
}

async function api(request, env) {
  const url = new URL(request.url), path = url.pathname, method = request.method, DB = env.DB;
  if (!DB || !env.ADMIN_PASSWORD || !env.SESSION_SECRET) return json({ error: 'Admin backend not configured (D1 binding / secrets).' }, 500);
  await ensureSchema(env);
  if (method !== 'GET') { // CSRF defence on top of SameSite=Strict
    const o = request.headers.get('origin');
    if ((o && o !== url.origin) || request.headers.get('x-vm-admin') !== '1') return json({ error: 'Forbidden' }, 403);
  }

  if (path === '/api/admin/login' && method === 'POST') {
    const key = await hmac(request.headers.get('CF-Connecting-IP') || 'unknown', env.SESSION_SECRET), t = Date.now();
    const a = await DB.prepare('SELECT window_start,blocked_until FROM login_attempts WHERE ip_key=?').bind(key).first();
    if (a?.blocked_until > t) return json({ error: 'Too many attempts. Try again in 15 minutes.' }, 429);
    if (!a || t - a.window_start > 900000) await DB.prepare('INSERT INTO login_attempts (ip_key,attempts,window_start,blocked_until) VALUES (?,0,?,0) ON CONFLICT(ip_key) DO UPDATE SET attempts=0,window_start=excluded.window_start,blocked_until=0').bind(key, t).run();
    const pw = String((await body(request)).password || '');
    // compare HMACs so length/timing of the real password never leaks
    if (!eq(await hmac(pw, env.SESSION_SECRET), await hmac(String(env.ADMIN_PASSWORD), env.SESSION_SECRET))) {
      const u = await DB.prepare('UPDATE login_attempts SET attempts=attempts+1 WHERE ip_key=? RETURNING attempts').bind(key).first();
      if (u?.attempts >= 5) await DB.prepare('UPDATE login_attempts SET blocked_until=? WHERE ip_key=?').bind(t + 900000, key).run();
      return json({ error: 'Invalid credentials' }, 401);
    }
    await DB.prepare('DELETE FROM login_attempts WHERE ip_key=?').bind(key).run();
    const payload = `${rnd(32)}.${Math.floor(t / 1000) + 8 * 3600}`;
    return json({ ok: true }, 200, { 'set-cookie': `${COOKIE}=${payload}.${await hmac(payload, env.SESSION_SECRET)}; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=28800` });
  }
  if (path === '/api/admin/logout' && method === 'POST') return json({ ok: true }, 200, { 'set-cookie': `${COOKIE}=; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=0` });
  if (!await isAdmin(request, env)) return json({ error: 'Admin login required' }, 401);

  if (path === '/api/admin/me') return json({ ok: true });
  if (path === '/api/admin/stats') {
    const { results = [] } = await DB.prepare('SELECT status,COUNT(*) n,COALESCE(SUM(total),0) s FROM orders GROUP BY status').all();
    const c = await DB.prepare('SELECT COUNT(*) n FROM coupons WHERE active=1').first();
    return json({ byStatus: results, activeCoupons: c.n });
  }
  if (path === '/api/admin/orders' && method === 'GET') {
    const { results = [] } = await DB.prepare('SELECT id,customer_name,location,phone,email,items,subtotal,discount,total,coupon,code,status,created_at FROM orders ORDER BY created_at DESC LIMIT 300').all();
    return json(results.map(x => ({ ...x, items: JSON.parse(x.items) })));
  }
  if (path === '/api/admin/verify' && method === 'POST') {
    const code = clean((await body(request)).code, 20).toUpperCase();
    if (!/^VM[A-Z2-9]{16}HE$/.test(code)) return json({ valid: false });
    const r = await DB.prepare('SELECT id,customer_name,location,phone,email,items,total,coupon,status,created_at FROM orders WHERE code=?').bind(code).first();
    return json(r ? { valid: true, ...r, items: JSON.parse(r.items) } : { valid: false });
  }
  let m = path.match(/^\/api\/admin\/orders\/([A-Za-z0-9-]+)\/status$/);
  if (m && method === 'POST') {
    const s = clean((await body(request)).status, 20);
    if (!['verified', 'rejected', 'payment_submitted'].includes(s)) return json({ error: 'Invalid status' }, 400);
    const r = await DB.prepare('UPDATE orders SET status=? WHERE id=? AND code IS NOT NULL').bind(s, m[1]).run();
    return r.meta.changes ? json({ ok: true }) : json({ error: 'Order has no payment code yet' }, 404);
  }

  // ---- coupons
  if (path === '/api/admin/coupons' && method === 'GET') return json((await DB.prepare('SELECT code,discount,active,created_at FROM coupons ORDER BY created_at DESC').all()).results);
  if (path === '/api/admin/coupons' && method === 'POST') {
    const d = await body(request), code = clean(d.code, 6).toUpperCase(), pct = Number(d.discount);
    if (!/^[A-Z0-9]{6}$/.test(code) || !pctOk(pct)) return json({ error: 'Code must be exactly 6 letters/numbers; discount 1–90%.' }, 400);
    try { await DB.prepare('INSERT INTO coupons (code,discount,created_at) VALUES (?,?,?)').bind(code, pct, now()).run(); } catch { return json({ error: 'That coupon already exists.' }, 409); }
    return json({ ok: true, code, discount: pct });
  }
  if (path === '/api/admin/coupons/random' && method === 'POST') {
    const pct = Number((await body(request)).discount);
    if (!pctOk(pct)) return json({ error: 'Enter a discount between 1 and 90.' }, 400);
    for (let i = 0; i < 20; i++) { const code = rnd(6); try { await DB.prepare('INSERT INTO coupons (code,discount,created_at) VALUES (?,?,?)').bind(code, pct, now()).run(); return json({ ok: true, code, discount: pct }); } catch {} }
    return json({ error: 'Could not generate a unique coupon.' }, 500);
  }
  m = path.match(/^\/api\/admin\/coupons\/([A-Za-z0-9]{6})$/);
  if (m && method === 'PATCH') { const r = await DB.prepare('UPDATE coupons SET active=? WHERE code=?').bind((await body(request)).active ? 1 : 0, m[1].toUpperCase()).run(); return r.meta.changes ? json({ ok: true }) : json({ error: 'Not found' }, 404); }
  if (m && method === 'DELETE') { await DB.prepare('DELETE FROM coupons WHERE code=?').bind(m[1].toUpperCase()).run(); return json({ ok: true }); }

  // ---- ranks (what the store sells)
  if (path === '/api/admin/ranks' && method === 'GET') return json((await DB.prepare('SELECT * FROM ranks ORDER BY sort,name').all()).results);
  const rankFields = d => ({ price: Number(d.price), tier: clean(d.tier, 30), description: clean(d.description, 80), icon: clean(d.icon, 4) || '✦', active: d.active === false ? 0 : 1, sort: Number.isInteger(Number(d.sort)) ? Number(d.sort) : 0 });
  if (path === '/api/admin/ranks' && method === 'POST') {
    const d = await body(request), name = clean(d.name, 16).toUpperCase(), f = rankFields(d);
    if (!/^[A-Z0-9]{3,16}$/.test(name) || !Number.isInteger(f.price) || f.price < 1 || f.price > 100000) return json({ error: 'Name: 3–16 letters/numbers. Price: whole rupees 1–100000.' }, 400);
    try { await DB.prepare('INSERT INTO ranks (name,price,tier,description,icon,active,sort) VALUES (?,?,?,?,?,?,?)').bind(name, f.price, f.tier, f.description, f.icon, f.active, f.sort).run(); } catch { return json({ error: 'Rank already exists.' }, 409); }
    return json({ ok: true });
  }
  m = path.match(/^\/api\/admin\/ranks\/([A-Z0-9]{3,16})$/);
  if (m && method === 'PUT') {
    const f = rankFields(await body(request));
    if (!Number.isInteger(f.price) || f.price < 1 || f.price > 100000) return json({ error: 'Price must be whole rupees 1–100000.' }, 400);
    const r = await DB.prepare('UPDATE ranks SET price=?,tier=?,description=?,icon=?,active=?,sort=? WHERE name=?').bind(f.price, f.tier, f.description, f.icon, f.active, f.sort, m[1]).run();
    return r.meta.changes ? json({ ok: true }) : json({ error: 'Not found' }, 404);
  }
  if (m && method === 'DELETE') { await DB.prepare('DELETE FROM ranks WHERE name=?').bind(m[1]).run(); return json({ ok: true }); }

  // ---- store settings
  if (path === '/api/admin/settings' && method === 'GET') {
    const { results = [] } = await DB.prepare("SELECT key,value FROM settings WHERE key IN ('upi_id','banner')").all();
    return json(Object.fromEntries(results.map(r => [r.key, r.value])));
  }
  if (path === '/api/admin/settings' && method === 'PUT') {
    const d = await body(request);
    for (const [k, v, max] of [['upi_id', d.upi_id, 100], ['banner', d.banner, 160]])
      await DB.prepare('INSERT INTO settings (key,value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value').bind(k, clean(v, max)).run();
    return json({ ok: true });
  }
  return json({ error: 'Not found' }, 404);
}

export default {
  async fetch(request, env) {
    if (new URL(request.url).pathname.startsWith('/api/')) {
      try { return await api(request, env); } catch (e) { console.error(e); return json({ error: 'Server error' }, 500); }
    }
    return env.ASSETS.fetch(request);
  }
};
