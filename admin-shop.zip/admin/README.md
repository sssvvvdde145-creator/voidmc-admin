# VOID MC — Store + Admin Dashboard (Cloudflare Workers + D1)

```
store/  -> shop.voidmc.bond   public rank store + public API (NO admin code at all)
admin/  -> admin.voidmc.bond  admin dashboard + admin API (separate Worker)
Both Workers use the SAME D1 database (void-mc-store-db), so everything is connected:
ranks, prices, banner, UPI ID, orders, payment codes and coupons edited in admin appear live on the store.
```

## Deploy (run each command from the folder shown)
1. `cd store && npm install && npx wrangler login`
2. Database ID is already set in both wrangler.jsonc files. If the database does not exist yet, create it first: `npx wrangler d1 create void-mc-store-db`.
3. Tables are created automatically on the first request (no SQL step needed).
4. `npm run deploy`   then in Cloudflare: Workers & Pages -> void-mc-store -> Settings -> Domains & Routes -> Custom domain `shop.voidmc.bond`
5. `cd ../admin && npm install`
6. Set the secrets (typed into the terminal prompt, never into any file):
   - `npx wrangler secret put ADMIN_PASSWORD`   <- enter your admin password
   - `npx wrangler secret put SESSION_SECRET`   <- a long random string (32+ chars), different from the password
7. `npm run deploy`   then add Custom domain `admin.voidmc.bond` to **void-mc-admin**.
Upgrading from the old ZIP: the old `ADMIN_PASSWORD`/`SESSION_SECRET` on the store Worker are no longer used; you can delete them.

## What was built
- **Payment codes**: after "I HAVE PAID" the customer gets a 20-char code `VM` + 16 random chars + `HE` (crypto-random, DB UNIQUE constraint, retry on clash), with a Copy button and Discord link. The old purchase prompt is gone.
- **Verify Payment Code** (admin only): valid/invalid, plus order, items, amount, customer, status; mark Verified / Rejected.
- **Login**: password only exists as a Worker secret; compared via HMAC (constant-time), 5 attempts then 15-min lockout, HttpOnly + Secure + SameSite=Strict `__Host-` cookie, 8h expiry, CSRF header + Origin check, strict CSP, noindex.
- **Coupons**: random (needs discount %) or custom, always exactly 6 chars, list, activate/deactivate/delete. Validated again on the server when the order is created, so client totals can't be faked.
- **Also manageable from admin**: ranks (price, text, icon, show/hide, add/delete), store banner, UPI ID, all orders.
- Footer credit "Made by HzardExecx!" and the clickable Discord link are on the store.

## Important notes
- A payment code proves the customer pressed the button, NOT that money arrived. Always match the amount in your UPI/bank app before pressing "Mark payment verified".
- Choose a long, random admin password. Short passwords that follow a pattern are easier to guess.

## Added admin controls
- Orders show the customer's Minecraft username and can be permanently deleted.
- Ranks support custom categories. Create a category first, then assign ranks to it; new ranks can be added and edited.
- Free SEAMAN claims are listed with player usernames and customer details. The shop Worker enforces the three-claim cap.
- The admin Worker and shop Worker must use the exact same D1 database binding/database ID.

## Free Rank manager (Admin Dashboard)
Open **Admin → Free Rank**. Everything is stored in the shared D1 `settings` table (`free_rank_*` keys), so the store picks changes up instantly, with no code edits or redeploy:
- **Rank name**, **price** (shown on the store as the rank's normal value; 0 hides it), **description**
- **Maximum claims** (default 3), enforced atomically in SQL so simultaneous claims can never exceed it
- **ON / OFF** switch: OFF hides the Free Rank card and blocks claims
- Live stats: status, claimed/max, remaining slots
- Every claimant: Minecraft username, customer name, email, phone, location, rank, time. A claim can be removed to free its slot.
Existing claims keep the rank name they were made under. API: `GET/PUT /api/admin/free-rank`, `DELETE /api/admin/free-claims/:id` (admin); `GET /api/free-rank`, `POST /api/free-rank/claim` (public store).


## V3.0.0

The admin dashboard now includes live announcement CRUD and website logo/background upload and removal. Create the shared Cloudflare R2 bucket `voidmc-media` and bind it as `MEDIA` in this Worker and the shop Worker. Both Workers must use the same D1 database and R2 bucket. Image uploads are restricted to PNG/JPG/WebP and 2 MB.
