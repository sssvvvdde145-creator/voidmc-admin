// XgenCloud Admin Worker (admin.xgencloud.bond). Shares the shop's D1 database and R2 bucket.
// Secrets: ADMIN_PASSWORD (initial password), SESSION_SECRET. After the first login the password
// hash lives in D1 (settings.admin_password_hash) and can be changed from the Panel; the secret
// remains only a fallback for the very first login.

// Auto-creates all tables on first request (safe to run every time), so no manual SQL step is needed.
const SCHEMA = [
 "CREATE TABLE IF NOT EXISTS orders (id TEXT PRIMARY KEY, customer_name TEXT NOT NULL, location TEXT NOT NULL, phone TEXT NOT NULL, email TEXT NOT NULL, items TEXT NOT NULL, subtotal INTEGER NOT NULL, discount INTEGER NOT NULL, total INTEGER NOT NULL, coupon TEXT, prompt TEXT NOT NULL, code TEXT UNIQUE, status TEXT NOT NULL DEFAULT 'awaiting_payment', created_at TEXT NOT NULL)",
 "CREATE INDEX IF NOT EXISTS idx_orders_created_at ON orders(created_at)",
 "CREATE INDEX IF NOT EXISTS idx_orders_code ON orders(code)",
 "CREATE TABLE IF NOT EXISTS coupons (code TEXT PRIMARY KEY, discount INTEGER NOT NULL CHECK(discount BETWEEN 1 AND 90), active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL)",
 "CREATE TABLE IF NOT EXISTS login_attempts (ip_key TEXT PRIMARY KEY, attempts INTEGER NOT NULL DEFAULT 0, window_start INTEGER NOT NULL, blocked_until INTEGER NOT NULL DEFAULT 0)",
 "CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL)",
 "CREATE TABLE IF NOT EXISTS announcements (id TEXT PRIMARY KEY,message TEXT NOT NULL,active INTEGER NOT NULL DEFAULT 1,created_at TEXT NOT NULL,updated_at TEXT NOT NULL)",
 "CREATE TABLE IF NOT EXISTS shop_categories (id TEXT PRIMARY KEY, name TEXT NOT NULL, description TEXT NOT NULL DEFAULT '', image_key TEXT NOT NULL DEFAULT '', parent_id TEXT NOT NULL DEFAULT '', enabled INTEGER NOT NULL DEFAULT 1, sort INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL, updated_at TEXT NOT NULL)",
 "CREATE INDEX IF NOT EXISTS idx_shop_categories_parent ON shop_categories(parent_id, sort)",
 "CREATE TABLE IF NOT EXISTS shop_products (id TEXT PRIMARY KEY, name TEXT NOT NULL, description TEXT NOT NULL DEFAULT '', specs TEXT NOT NULL DEFAULT '', price_monthly INTEGER NOT NULL DEFAULT 0, price_quarterly INTEGER NOT NULL DEFAULT 0, price_yearly INTEGER NOT NULL DEFAULT 0, image_key TEXT NOT NULL DEFAULT '', category_id TEXT NOT NULL DEFAULT '', subcategory_id TEXT NOT NULL DEFAULT '', stock INTEGER NOT NULL DEFAULT -1, enabled INTEGER NOT NULL DEFAULT 1, featured INTEGER NOT NULL DEFAULT 0, sort INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL, updated_at TEXT NOT NULL)",
 "CREATE INDEX IF NOT EXISTS idx_shop_products_category ON shop_products(category_id, subcategory_id, sort)",
 "CREATE TABLE IF NOT EXISTS ip_bans (id TEXT PRIMARY KEY, ip TEXT NOT NULL, reason TEXT NOT NULL DEFAULT '', banned_by TEXT NOT NULL DEFAULT 'admin', status TEXT NOT NULL DEFAULT 'active', created_at TEXT NOT NULL, updated_at TEXT NOT NULL, unbanned_at TEXT NOT NULL DEFAULT '', unbanned_by TEXT NOT NULL DEFAULT '')",
 "CREATE INDEX IF NOT EXISTS idx_ip_bans_ip ON ip_bans(ip, created_at)",
 "CREATE INDEX IF NOT EXISTS idx_ip_bans_status ON ip_bans(status)",
 "CREATE TABLE IF NOT EXISTS admin_activity_log (id TEXT PRIMARY KEY, action TEXT NOT NULL, detail TEXT NOT NULL DEFAULT '', actor TEXT NOT NULL DEFAULT 'admin', created_at TEXT NOT NULL)",
 "CREATE INDEX IF NOT EXISTS idx_activity_created ON admin_activity_log(created_at)",
 "CREATE TABLE IF NOT EXISTS rate_limits (key TEXT PRIMARY KEY, count INTEGER NOT NULL DEFAULT 0, window_start INTEGER NOT NULL)",
 "INSERT OR IGNORE INTO settings(key,value) VALUES ('logo_key',''),('background_key','')",
 "INSERT OR IGNORE INTO settings (key,value) VALUES ('maintenance_enabled','0'),('maintenance_message','We are performing scheduled maintenance to improve XgenCloud. Please check back soon.'),('maintenance_updated_at','')",
 "INSERT OR IGNORE INTO settings (key,value) VALUES ('music_enabled','0'),('music_key',''),('music_name',''),('music_type',''),('music_size','0'),('music_version',''),('music_updated_at','')",
 "INSERT OR IGNORE INTO settings (key,value) VALUES ('discord_invite','https://discord.gg/kBHUk8FcB')",
 "INSERT OR IGNORE INTO settings (key,value) VALUES ('payment_qr_key',''),('payment_qr_version','')"
];
let schemaReady;
const ensureSchema = env => schemaReady ||= (async()=>{await env.DB.batch(SCHEMA.map(s=>env.DB.prepare(s)));const ocols=(await env.DB.prepare('PRAGMA table_info(orders)').all()).results||[];if(!ocols.some(c=>c.name==='minecraft_username'))await env.DB.prepare("ALTER TABLE orders ADD COLUMN minecraft_username TEXT NOT NULL DEFAULT ''").run();})().catch(e=>{schemaReady=null;throw e});

const COOKIE = '__Host-xgen_admin', ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const json = (d, s = 200, h = {}) => new Response(JSON.stringify(d), { status: s, headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', ...h } });
const clean = (v, m = 120) => String(v ?? '').trim().slice(0, m);
const now = () => new Date().toISOString();
const hex = b => [...new Uint8Array(b)].map(x => x.toString(16).padStart(2, '0')).join('');
const rnd = n => [...crypto.getRandomValues(new Uint8Array(n))].map(b => ALPHABET[b % 32]).join('');
async function hmac(v, secret) {
  const k = await crypto.subtle.importKey('raw', new TextEncoder().encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  return hex(await crypto.subtle.sign('HMAC', k, new TextEncoder().encode(v)));
}
const eq = (a, b) => { if (a.length !== b.length) return false; let o = 0; for (let i = 0; i < a.length; i++) o |= a.charCodeAt(i) ^ b.charCodeAt(i); return o === 0; };
const body = async r => { try { return await r.json(); } catch { return {}; } };
const pctOk = n => Number.isInteger(n) && n >= 1 && n <= 90;

// ---- Admin password: PBKDF2-SHA256 hash stored in D1 (never the plain password, never in code).
const PBKDF2_ITERATIONS = 100000;
async function pbkdf2(password, saltHex, iterations) {
  const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(password), 'PBKDF2', false, ['deriveBits']);
  const bits = await crypto.subtle.deriveBits({ name: 'PBKDF2', salt: Uint8Array.from(saltHex.match(/../g).map(x => parseInt(x, 16))), iterations, hash: 'SHA-256' }, key, 256);
  return hex(new Uint8Array(bits));
}
async function hashPassword(password) {
  const salt = hex(crypto.getRandomValues(new Uint8Array(16)));
  return `v1:${PBKDF2_ITERATIONS}:${salt}:${await pbkdf2(password, salt, PBKDF2_ITERATIONS)}`;
}
async function verifyStoredPassword(password, stored) {
  const [v, it, salt, hash] = String(stored || '').split(':');
  if (v !== 'v1' || !/^\d+$/.test(it || '') || !/^[0-9a-f]{32}$/.test(salt || '') || !/^[0-9a-f]{64}$/.test(hash || '')) return false;
  return eq(await pbkdf2(password, salt, Number(it)), hash);
}
// Verifies a login candidate. Returns true/false. On a successful first login against the
// Worker secret, seeds the D1 hash so the password can be changed from the Panel afterwards.
async function checkAdminPassword(DB, env, candidate) {
  const stored = (await DB.prepare("SELECT value FROM settings WHERE key='admin_password_hash'").first())?.value || '';
  if (stored) return verifyStoredPassword(candidate, stored);
  // Initial login: compare against the secret (constant-time, via HMAC), then seed the hash.
  if (!env.ADMIN_PASSWORD || !candidate) return false;
  if (!eq(await hmac(candidate, env.SESSION_SECRET), await hmac(String(env.ADMIN_PASSWORD), env.SESSION_SECRET))) return false;
  try { await DB.prepare("INSERT INTO settings (key,value) VALUES ('admin_password_hash',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value").bind(await hashPassword(candidate)).run(); } catch (e) { console.error('password hash seed failed', e); }
  return true;
}

async function logActivity(DB, action, detail, actor = 'admin') {
  try { await DB.prepare('INSERT INTO admin_activity_log (id,action,detail,actor,created_at) VALUES (?,?,?,?,?)').bind('act-' + hex(crypto.getRandomValues(new Uint8Array(8))), clean(action, 60), clean(detail, 300), clean(actor, 60), now()).run(); }
  catch (e) { console.error('activity log failed', e); }
}

// ---- Maintenance Mode (shared `settings` table; the store Worker reads the same keys live on every request)
const MAINT_DEFAULT_MSG = 'We are performing scheduled maintenance to improve XgenCloud. Please check back soon.';
async function maintenanceState(DB) {
  const { results = [] } = await DB.prepare("SELECT key,value FROM settings WHERE key IN ('maintenance_enabled','maintenance_message','maintenance_updated_at')").all();
  const m = Object.fromEntries(results.map(r => [r.key, r.value]));
  return { enabled: m.maintenance_enabled === '1', message: clean(m.maintenance_message, 500) || MAINT_DEFAULT_MSG, updatedAt: m.maintenance_updated_at || '' };
}

async function isAdmin(request, env) {
  const raw = (request.headers.get('Cookie') || '').split(';').map(x => x.trim()).find(x => x.startsWith(COOKIE + '='))?.slice(COOKIE.length + 1);
  const [t, exp, sig] = (raw || '').split('.');
  if (!t || !/^\d+$/.test(exp || '') || !sig || Number(exp) < Date.now() / 1000) return false;
  return eq(sig, await hmac(`${t}.${exp}`, env.SESSION_SECRET));
}

// ---- Background music. Flags live in the shared `settings` table, the audio file in the shared R2 bucket (MEDIA);
// the shop Worker reads the same keys and streams the file to visitors.
const MUSIC_MAX = 15 * 1024 * 1024;   // 15 MB: big enough for a full track, small enough to stay fast on mobile data
const MUSIC_FORMATS = {               // what the file CONTENT is -> the content type we serve + the extensions we accept for it
  mp3: { type: 'audio/mpeg', label: 'MP3', ext: ['mp3'] },
  aac: { type: 'audio/aac', label: 'AAC', ext: ['aac'] },
  m4a: { type: 'audio/mp4', label: 'M4A', ext: ['m4a', 'mp4', 'aac'] },
  wav: { type: 'audio/wav', label: 'WAV', ext: ['wav', 'wave'] },
  ogg: { type: 'audio/ogg', label: 'OGG', ext: ['ogg', 'oga', 'opus'] }
};
// One MPEG audio / ADTS frame header at offset i? Returns 'mp3' | 'aac' | ''.
function mpegFrame(b, i) {
  if (i + 3 >= b.length || b[i] !== 0xFF || (b[i + 1] & 0xE0) !== 0xE0) return '';
  const ver = (b[i + 1] >> 3) & 3, layer = (b[i + 1] >> 1) & 3, br = (b[i + 2] >> 4) & 15, sr = (b[i + 2] >> 2) & 3;
  if (layer === 0) return (b[i + 1] & 0xF6) === 0xF0 && ((b[i + 2] >> 2) & 15) <= 12 ? 'aac' : '';   // ADTS AAC
  return ver === 1 || br === 15 || sr === 3 ? '' : 'mp3';
}
// Identify the audio format from the file's own bytes (the browser-supplied type and the file name are never trusted).
function sniffAudio(b) {
  if (b.length < 16) return '';
  const s = (o, n) => String.fromCharCode(...b.subarray(o, o + n));
  if (s(0, 4) === 'OggS') return 'ogg';
  if (s(0, 4) === 'RIFF' && s(8, 4) === 'WAVE') return 'wav';
  if (s(4, 4) === 'ftyp' && ['M4A ', 'M4B ', 'mp42', 'mp41', 'isom', 'iso2'].includes(s(8, 4))) return 'm4a';
  if (s(0, 3) === 'ID3') {   // ID3v2 tag first: the first real audio frame must follow it
    const start = 10 + (((b[6] & 127) << 21) | ((b[7] & 127) << 14) | ((b[8] & 127) << 7) | (b[9] & 127)) + ((b[5] & 16) ? 10 : 0);
    for (let i = start; i <= Math.min(b.length - 4, start + 4096); i++) { const f = mpegFrame(b, i); if (f) return f; }
    return '';
  }
  return mpegFrame(b, 0);
}
// Read the request body but give up as soon as it exceeds `max` bytes (a Content-Length header can lie).
async function readCapped(request, max) {
  if (Number(request.headers.get('content-length') || 0) > max) return null;
  if (!request.body) return new Uint8Array(0);
  const reader = request.body.getReader(), chunks = [];
  let total = 0;
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    total += value.byteLength;
    if (total > max) { await reader.cancel().catch(() => {}); return null; }
    chunks.push(value);
  }
  const out = new Uint8Array(total);
  let o = 0; for (const c of chunks) { out.set(c, o); o += c.byteLength; }
  return out;
}
async function musicState(DB) {
  const { results = [] } = await DB.prepare("SELECT key,value FROM settings WHERE key LIKE 'music\\_%' ESCAPE '\\'").all();
  const m = Object.fromEntries(results.map(r => [r.key, r.value]));
  return { enabled: m.music_enabled === '1' && !!m.music_key, hasFile: !!m.music_key, name: m.music_name || '', type: m.music_type || '', size: Number(m.music_size) || 0, version: m.music_version || '', updatedAt: m.music_updated_at || '' };
}
const upsert = (DB, k, v) => DB.prepare('INSERT INTO settings (key,value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value').bind(k, String(v));
function contentRange(r, size) {
  if (!r) return null;
  let start, end;
  if (r.suffix !== undefined) { start = Math.max(0, size - r.suffix); end = size - 1; }
  else { start = r.offset ?? 0; end = r.length !== undefined ? Math.min(size - 1, start + r.length - 1) : size - 1; }
  return `bytes ${start}-${end}/${size}`;
}
// ---- Image upload (category/product images): validate by content bytes, store in R2 under a random key.
function sniffImage(bytes) {
  if (bytes.length > 8 && [137, 80, 78, 71, 13, 10, 26, 10].every((v, i) => bytes[i] === v)) return 'image/png';
  if (bytes.length > 3 && bytes[0] === 255 && bytes[1] === 216 && bytes[2] === 255) return 'image/jpeg';
  if (bytes.length > 12 && String.fromCharCode(...bytes.slice(0, 4)) === 'RIFF' && String.fromCharCode(...bytes.slice(8, 12)) === 'WEBP') return 'image/webp';
  return '';
}
async function saveImage(env, dataUrl) {
  if (!env.MEDIA) return { error: 'R2 MEDIA bucket binding is missing.', status: 503 };
  const match = String(dataUrl || '').match(/^data:(image\/(?:png|jpeg|webp));base64,([A-Za-z0-9+/=]+)$/);
  if (!match) return { error: 'Only PNG, JPG and WebP images are allowed.', status: 400 };
  const bytes = Uint8Array.from(atob(match[2]), c => c.charCodeAt(0));
  if (bytes.length > 2 * 1024 * 1024) return { error: 'Image must be 2 MB or smaller.', status: 413 };
  if (sniffImage(bytes) !== match[1]) return { error: 'The uploaded file is not a valid PNG, JPG or WebP image.', status: 400 };
  const key = `xgencloud/images/${Date.now()}-${hex(crypto.getRandomValues(new Uint8Array(8)))}`;
  await env.MEDIA.put(key, bytes, { httpMetadata: { contentType: match[1] } });
  return { key };
}
async function deleteImage(env, key) {
  if (key && env.MEDIA && /^xgencloud\/images\/[A-Za-z0-9._-]+$/.test(key)) await env.MEDIA.delete(key).catch(() => {});
}
const DISCORD_RE = /^https:\/\/(discord\.gg\/|discord\.com\/invite\/)[A-Za-z0-9-]{2,64}$/;
const IPV4_RE = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/;
function validIp(ip) {
  const v4 = ip.match(IPV4_RE);
  if (v4) return v4.slice(1).every(o => Number(o) <= 255);
  return ip.length >= 3 && ip.length <= 45 && /^[0-9a-fA-F:]+$/.test(ip) && ip.includes(':');
}

async function api(request, env) {
  const url = new URL(request.url), path = url.pathname, method = request.method, DB = env.DB;
  if (!DB || !env.SESSION_SECRET) return json({ error: 'Admin backend not configured (D1 binding / SESSION_SECRET).' }, 500);
  await ensureSchema(env);
  if (method !== 'GET') { // CSRF defence on top of SameSite=Strict
    const o = request.headers.get('origin');
    if ((o && o !== url.origin) || request.headers.get('x-xgen-admin') !== '1') return json({ error: 'Forbidden' }, 403);
  }

  if (path === '/api/admin/login' && method === 'POST') {
    const key = await hmac(request.headers.get('CF-Connecting-IP') || 'unknown', env.SESSION_SECRET), t = Date.now();
    const a = await DB.prepare('SELECT window_start,blocked_until FROM login_attempts WHERE ip_key=?').bind(key).first();
    if (a?.blocked_until > t) return json({ error: 'Too many attempts. Try again in 15 minutes.' }, 429);
    if (!a || t - a.window_start > 900000) await DB.prepare('INSERT INTO login_attempts (ip_key,attempts,window_start,blocked_until) VALUES (?,0,?,0) ON CONFLICT(ip_key) DO UPDATE SET attempts=0,window_start=excluded.window_start,blocked_until=0').bind(key, t).run();
    const pw = String((await body(request)).password || '');
    if (!await checkAdminPassword(DB, env, pw)) {
      const u = await DB.prepare('UPDATE login_attempts SET attempts=attempts+1 WHERE ip_key=? RETURNING attempts').bind(key).first();
      if (u?.attempts >= 5) await DB.prepare('UPDATE login_attempts SET blocked_until=? WHERE ip_key=?').bind(t + 900000, key).run();
      return json({ error: 'Invalid credentials' }, 401);
    }
    await DB.prepare('DELETE FROM login_attempts WHERE ip_key=?').bind(key).run();
    const payload = `${rnd(32)}.${Math.floor(t / 1000) + 8 * 3600}`;
    return json({ ok: true }, 200, { 'set-cookie': `${COOKIE}=${payload}.${await hmac(payload, env.SESSION_SECRET)}; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=28800` });
  }
  if (path === '/api/admin/logout' && method === 'POST') return json({ ok: true }, 200, { 'set-cookie': `${COOKIE}=; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=0` });
  if (!await isAdmin(request, env)) return json({ error: 'Admin login required' }, 401);

  if (path === '/api/admin/me') return json({ ok: true });

  // ---- Change admin password (current password required; stored only as a PBKDF2 hash in D1)
  if (path === '/api/admin/password' && method === 'PUT') {
    const d = await body(request), current = String(d.current || ''), next = String(d.next || '');
    if (!await checkAdminPassword(DB, env, current)) return json({ error: 'Current password is incorrect.' }, 403);
    if (next.length < 8 || next.length > 128) return json({ error: 'New password must be 8-128 characters.' }, 400);
    await DB.prepare("INSERT INTO settings (key,value) VALUES ('admin_password_hash',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value").bind(await hashPassword(next)).run();
    await logActivity(DB, 'password_change', 'Admin password changed');
    return json({ ok: true });
  }

  // ---- Activity log (read-only)
  if (path === '/api/admin/activity' && method === 'GET') {
    return json((await DB.prepare('SELECT action,detail,actor,created_at FROM admin_activity_log ORDER BY created_at DESC LIMIT 200').all()).results || []);
  }

  if (path === '/api/admin/maintenance' && method === 'GET') return json(await maintenanceState(DB));
  if (path === '/api/admin/maintenance' && method === 'PUT') {
    const d = await body(request), cur = await maintenanceState(DB);
    if (d.enabled !== undefined && typeof d.enabled !== 'boolean') return json({ error: 'Enabled must be true or false.' }, 400);
    if (d.message !== undefined && typeof d.message !== 'string') return json({ error: 'Message must be text.' }, 400);
    const message = d.message === undefined ? cur.message : clean(d.message, 500);
    if (!message) return json({ error: 'Enter a maintenance reason/message.' }, 400);
    const enabled = d.enabled === undefined ? cur.enabled : d.enabled;
    await DB.batch([['maintenance_enabled', enabled ? '1' : '0'], ['maintenance_message', message], ['maintenance_updated_at', now()]]
      .map(([k, v]) => DB.prepare('INSERT INTO settings (key,value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value').bind(k, v)));
    return json({ ok: true, ...(await maintenanceState(DB)) });
  }

  if (path === '/api/admin/stats') {
    const { results = [] } = await DB.prepare('SELECT status,COUNT(*) n,COALESCE(SUM(total),0) s FROM orders GROUP BY status').all();
    const c = await DB.prepare('SELECT COUNT(*) n FROM coupons WHERE active=1').first();
    const cats = await DB.prepare('SELECT COUNT(*) n FROM shop_categories').first();
    const prods = await DB.prepare('SELECT COUNT(*) n FROM shop_products').first();
    const bans = await DB.prepare("SELECT COUNT(DISTINCT ip) n FROM ip_bans WHERE status='active'").first();
    return json({ byStatus: results, activeCoupons: c.n, categories: cats.n, products: prods.n, bannedIps: bans.n, maintenance: (await maintenanceState(DB)).enabled });
  }
  if (path === '/api/admin/orders' && method === 'GET') {
    const { results = [] } = await DB.prepare('SELECT id,customer_name,location,phone,minecraft_username,email,items,subtotal,discount,total,coupon,code,status,created_at FROM orders ORDER BY created_at DESC LIMIT 300').all();
    return json(results.map(x => ({ ...x, items: JSON.parse(x.items) })));
  }
  let m = path.match(/^\/api\/admin\/orders\/([A-Za-z0-9-]+)$/);
  if (m && method === 'DELETE') { const r = await DB.prepare('DELETE FROM orders WHERE id=?').bind(m[1]).run(); return r.meta.changes ? json({ ok: true }) : json({ error: 'Order not found' }, 404); }
  if (path === '/api/admin/verify' && method === 'POST') {
    const code = clean((await body(request)).code, 20).toUpperCase();
    if (!/^(VM[A-Z2-9]{16}HE|XG[A-Z2-9]{16}CL)$/.test(code)) return json({ valid: false });
    const r = await DB.prepare('SELECT id,customer_name,location,phone,minecraft_username,email,items,total,coupon,status,created_at FROM orders WHERE code=?').bind(code).first();
    return json(r ? { valid: true, ...r, items: JSON.parse(r.items) } : { valid: false });
  }
  m = path.match(/^\/api\/admin\/orders\/([A-Za-z0-9-]+)\/status$/);
  if (m && method === 'POST') {
    const s = clean((await body(request)).status, 20);
    if (!['verified', 'rejected', 'payment_submitted'].includes(s)) return json({ error: 'Invalid status' }, 400);
    const r = await DB.prepare('UPDATE orders SET status=? WHERE id=? AND code IS NOT NULL').bind(s, m[1]).run();
    return r.meta.changes ? json({ ok: true }) : json({ error: 'Order has no payment code yet' }, 404);
  }

  // ---- coupons
  if (path === '/api/admin/coupons' && method === 'GET') return json((await DB.prepare('SELECT code,discount,active,created_at FROM coupons ORDER BY created_at DESC').all()).results);
  if (path === '/api/admin/coupons' && method === 'POST') {
    const d = await body(request), code = clean(d.code, 6).toUpperCase(), pct = Number(d.discount);
    if (!/^[A-Z0-9]{6}$/.test(code) || !pctOk(pct)) return json({ error: 'Code must be exactly 6 letters/numbers; discount 1-90%.' }, 400);
    try { await DB.prepare('INSERT INTO coupons (code,discount,created_at) VALUES (?,?,?)').bind(code, pct, now()).run(); } catch { return json({ error: 'That coupon already exists.' }, 409); }
    return json({ ok: true, code, discount: pct });
  }
  if (path === '/api/admin/coupons/random' && method === 'POST') {
    const pct = Number((await body(request)).discount);
    if (!pctOk(pct)) return json({ error: 'Enter a discount between 1 and 90.' }, 400);
    for (let i = 0; i < 20; i++) { const code = rnd(6); try { await DB.prepare('INSERT INTO coupons (code,discount,created_at) VALUES (?,?,?)').bind(code, pct, now()).run(); return json({ ok: true, code, discount: pct }); } catch {} }
    return json({ error: 'Could not generate a unique coupon.' }, 500);
  }
  m = path.match(/^\/api\/admin\/coupons\/([A-Za-z0-9]{6})$/);
  if (m && method === 'PATCH') { const r = await DB.prepare('UPDATE coupons SET active=? WHERE code=?').bind((await body(request)).active ? 1 : 0, m[1].toUpperCase()).run(); return r.meta.changes ? json({ ok: true }) : json({ error: 'Not found' }, 404); }
  if (m && method === 'DELETE') { await DB.prepare('DELETE FROM coupons WHERE code=?').bind(m[1].toUpperCase()).run(); return json({ ok: true }); }

  // ---- Hosting categories (main + subcategories). The shop reads these live; nothing is hardcoded.
  if (path === '/api/admin/shop-categories' && method === 'GET') {
    return json((await DB.prepare('SELECT * FROM shop_categories ORDER BY parent_id,sort,name').all()).results || []);
  }
  if (path === '/api/admin/shop-categories' && method === 'POST') {
    const d = await body(request), name = clean(d.name, 40), description = clean(d.description, 200), parentId = clean(d.parentId, 60);
    if (name.length < 2) return json({ error: 'Category name must be at least 2 characters.' }, 400);
    const sort = Number.isInteger(Number(d.sort)) ? Number(d.sort) : 0;
    if (parentId) {
      const parent = await DB.prepare('SELECT id,parent_id FROM shop_categories WHERE id=?').bind(parentId).first();
      if (!parent) return json({ error: 'Parent category not found.' }, 404);
      if (parent.parent_id) return json({ error: 'Subcategories cannot have their own subcategories.' }, 400);
    }
    const id = 'cat-' + hex(crypto.getRandomValues(new Uint8Array(8)));
    await DB.prepare('INSERT INTO shop_categories (id,name,description,image_key,parent_id,enabled,sort,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?)')
      .bind(id, name, description, '', parentId, d.enabled === false ? 0 : 1, sort, now(), now()).run();
    await logActivity(DB, 'category_create', `Created category "${name}"${parentId ? ' (subcategory)' : ''}`);
    return json({ ok: true, id });
  }
  m = path.match(/^\/api\/admin\/shop-categories\/([A-Za-z0-9-]+)$/);
  if (m && method === 'PUT') {
    const d = await body(request), cur = await DB.prepare('SELECT * FROM shop_categories WHERE id=?').bind(m[1]).first();
    if (!cur) return json({ error: 'Category not found' }, 404);
    const name = d.name === undefined ? cur.name : clean(d.name, 40);
    if (name.length < 2) return json({ error: 'Category name must be at least 2 characters.' }, 400);
    const description = d.description === undefined ? cur.description : clean(d.description, 200);
    const sort = d.sort === undefined ? cur.sort : (Number.isInteger(Number(d.sort)) ? Number(d.sort) : cur.sort);
    const enabled = d.enabled === undefined ? cur.enabled : (d.enabled ? 1 : 0);
    await DB.prepare('UPDATE shop_categories SET name=?,description=?,enabled=?,sort=?,updated_at=? WHERE id=?').bind(name, description, enabled, sort, now(), cur.id).run();
    return json({ ok: true });
  }
  if (m && method === 'DELETE') {
    const cur = await DB.prepare('SELECT id,name FROM shop_categories WHERE id=?').bind(m[1]).first();
    if (!cur) return json({ error: 'Category not found' }, 404);
    const subs = await DB.prepare('SELECT COUNT(*) n FROM shop_categories WHERE parent_id=?').bind(cur.id).first();
    if (subs.n > 0) return json({ error: 'Delete or move its subcategories first.' }, 409);
    const prods = await DB.prepare('SELECT COUNT(*) n FROM shop_products WHERE category_id=? OR subcategory_id=?').bind(cur.id, cur.id).first();
    if (prods.n > 0) return json({ error: 'Delete or move the products in this category first.' }, 409);
    await DB.prepare('DELETE FROM shop_categories WHERE id=?').bind(cur.id).run();
    await logActivity(DB, 'category_delete', `Deleted category "${cur.name}"`);
    return json({ ok: true });
  }

  // ---- Category/product image attach (uploaded bytes go to R2; only the key is stored in D1)
  m = path.match(/^\/api\/admin\/shop-categories\/([A-Za-z0-9-]+)\/image$/);
  if (m && method === 'PUT') {
    const cur = await DB.prepare('SELECT id,image_key FROM shop_categories WHERE id=?').bind(m[1]).first();
    if (!cur) return json({ error: 'Category not found' }, 404);
    const d = await body(request);
    if (d.remove === true) { await deleteImage(env, cur.image_key); await DB.prepare("UPDATE shop_categories SET image_key='',updated_at=? WHERE id=?").bind(now(), cur.id).run(); return json({ ok: true }); }
    const saved = await saveImage(env, d.dataUrl);
    if (saved.error) return json({ error: saved.error }, saved.status);
    await DB.prepare('UPDATE shop_categories SET image_key=?,updated_at=? WHERE id=?').bind(saved.key, now(), cur.id).run();
    await deleteImage(env, cur.image_key);
    return json({ ok: true, key: saved.key, url: '/media/img/' + saved.key });
  }

  // ---- Hosting products
  if (path === '/api/admin/products' && method === 'GET') {
    return json((await DB.prepare('SELECT * FROM shop_products ORDER BY sort,name').all()).results || []);
  }
  const validPrice = n => Number.isInteger(n) && n >= 0 && n <= 10000000;
  async function productFields(d, cur) {
    const g = (k, def) => d[k] === undefined ? def : d[k];
    const f = {
      name: clean(g('name', cur?.name), 60),
      description: clean(g('description', cur?.description), 500),
      specs: clean(g('specs', cur?.specs), 1000),
      price_monthly: Number(g('price_monthly', cur?.price_monthly ?? 0)),
      price_quarterly: Number(g('price_quarterly', cur?.price_quarterly ?? 0)),
      price_yearly: Number(g('price_yearly', cur?.price_yearly ?? 0)),
      category_id: clean(g('category_id', cur?.category_id), 60),
      subcategory_id: clean(g('subcategory_id', cur?.subcategory_id), 60),
      stock: Number(g('stock', cur?.stock ?? -1)),
      enabled: g('enabled', cur?.enabled ?? 1) ? 1 : 0,
      featured: g('featured', cur?.featured ?? 0) ? 1 : 0,
      sort: Number.isInteger(Number(g('sort', cur?.sort ?? 0))) ? Number(g('sort', cur?.sort ?? 0)) : 0
    };
    if (f.name.length < 2) return { error: 'Product name must be at least 2 characters.' };
    if (!validPrice(f.price_monthly) || !validPrice(f.price_quarterly) || !validPrice(f.price_yearly)) return { error: 'Prices must be whole rupees (0-10000000); 0 means the period is not offered.' };
    if (f.price_monthly < 1 && f.price_quarterly < 1 && f.price_yearly < 1) return { error: 'Set a price for at least one billing period.' };
    if (!Number.isInteger(f.stock) || f.stock < -1 || f.stock > 1000000) return { error: 'Stock must be -1 (unlimited) or a whole number.' };
    if (f.category_id) {
      const cat = await DB.prepare('SELECT id,parent_id FROM shop_categories WHERE id=?').bind(f.category_id).first();
      if (!cat) return { error: 'Choose a valid category.' };
      if (cat.parent_id) return { error: 'Choose a main category; pick the subcategory separately.' };
    }
    if (f.subcategory_id) {
      const sub = await DB.prepare('SELECT id,parent_id FROM shop_categories WHERE id=?').bind(f.subcategory_id).first();
      if (!sub || !sub.parent_id) return { error: 'Choose a valid subcategory.' };
      if (f.category_id && sub.parent_id !== f.category_id) return { error: 'That subcategory does not belong to the chosen category.' };
      if (!f.category_id) f.category_id = sub.parent_id;
    }
    return { f };
  }
  if (path === '/api/admin/products' && method === 'POST') {
    const { f, error } = await productFields(await body(request), null);
    if (error) return json({ error }, 400);
    const id = 'prd-' + hex(crypto.getRandomValues(new Uint8Array(8)));
    await DB.prepare('INSERT INTO shop_products (id,name,description,specs,price_monthly,price_quarterly,price_yearly,image_key,category_id,subcategory_id,stock,enabled,featured,sort,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)')
      .bind(id, f.name, f.description, f.specs, f.price_monthly, f.price_quarterly, f.price_yearly, '', f.category_id, f.subcategory_id, f.stock, f.enabled, f.featured, f.sort, now(), now()).run();
    await logActivity(DB, 'product_create', `Created product "${f.name}"`);
    return json({ ok: true, id });
  }
  m = path.match(/^\/api\/admin\/products\/([A-Za-z0-9-]+)$/);
  if (m && method === 'PUT') {
    const cur = await DB.prepare('SELECT * FROM shop_products WHERE id=?').bind(m[1]).first();
    if (!cur) return json({ error: 'Product not found' }, 404);
    const { f, error } = await productFields(await body(request), cur);
    if (error) return json({ error }, 400);
    await DB.prepare('UPDATE shop_products SET name=?,description=?,specs=?,price_monthly=?,price_quarterly=?,price_yearly=?,category_id=?,subcategory_id=?,stock=?,enabled=?,featured=?,sort=?,updated_at=? WHERE id=?')
      .bind(f.name, f.description, f.specs, f.price_monthly, f.price_quarterly, f.price_yearly, f.category_id, f.subcategory_id, f.stock, f.enabled, f.featured, f.sort, now(), cur.id).run();
    return json({ ok: true });
  }
  if (m && method === 'DELETE') {
    const cur = await DB.prepare('SELECT id,name,image_key FROM shop_products WHERE id=?').bind(m[1]).first();
    if (!cur) return json({ error: 'Product not found' }, 404);
    await DB.prepare('DELETE FROM shop_products WHERE id=?').bind(cur.id).run();
    await deleteImage(env, cur.image_key);
    await logActivity(DB, 'product_delete', `Deleted product "${cur.name}"`);
    return json({ ok: true });
  }
  m = path.match(/^\/api\/admin\/products\/([A-Za-z0-9-]+)\/image$/);
  if (m && method === 'PUT') {
    const cur = await DB.prepare('SELECT id,image_key FROM shop_products WHERE id=?').bind(m[1]).first();
    if (!cur) return json({ error: 'Product not found' }, 404);
    const d = await body(request);
    if (d.remove === true) { await deleteImage(env, cur.image_key); await DB.prepare("UPDATE shop_products SET image_key='',updated_at=? WHERE id=?").bind(now(), cur.id).run(); return json({ ok: true }); }
    const saved = await saveImage(env, d.dataUrl);
    if (saved.error) return json({ error: saved.error }, saved.status);
    await DB.prepare('UPDATE shop_products SET image_key=?,updated_at=? WHERE id=?').bind(saved.key, now(), cur.id).run();
    await deleteImage(env, cur.image_key);
    return json({ ok: true, key: saved.key, url: '/media/img/' + saved.key });
  }

  // ---- IP Ban / Unban management. Every action is admin-only (guarded above) and written to the activity log.
  if (path === '/api/admin/ip-bans' && method === 'GET') {
    const q = clean(url.searchParams.get('q'), 45).toLowerCase(), status = clean(url.searchParams.get('status'), 10);
    let rows = (await DB.prepare('SELECT * FROM ip_bans ORDER BY created_at DESC LIMIT 500').all()).results || [];
    if (status === 'active' || status === 'unbanned') rows = rows.filter(r => r.status === status);
    if (q) rows = rows.filter(r => r.ip.toLowerCase().includes(q) || (r.reason || '').toLowerCase().includes(q));
    return json(rows);
  }
  if (path === '/api/admin/ip-bans' && method === 'POST') {
    const d = await body(request), ip = clean(d.ip, 45), reason = clean(d.reason, 200);
    if (!validIp(ip)) return json({ error: 'Enter a valid IPv4 or IPv6 address.' }, 400);
    const latest = await DB.prepare('SELECT status FROM ip_bans WHERE ip=? ORDER BY created_at DESC LIMIT 1').bind(ip).first();
    if (latest?.status === 'active') return json({ error: 'That IP address is already banned.' }, 409);
    const id = 'ban-' + hex(crypto.getRandomValues(new Uint8Array(8)));
    await DB.prepare("INSERT INTO ip_bans (id,ip,reason,banned_by,status,created_at,updated_at) VALUES (?,?,?,?,'active',?,?)").bind(id, ip, reason, 'admin', now(), now()).run();
    await logActivity(DB, 'ip_ban', `Banned ${ip}${reason ? ' - ' + reason : ''}`);
    return json({ ok: true, id });
  }
  m = path.match(/^\/api\/admin\/ip-bans\/([A-Za-z0-9-]+)$/);
  if (m && method === 'PUT') {  // edit the reason on a ban record
    const cur = await DB.prepare('SELECT * FROM ip_bans WHERE id=?').bind(m[1]).first();
    if (!cur) return json({ error: 'Ban record not found' }, 404);
    const reason = clean((await body(request)).reason, 200);
    await DB.prepare('UPDATE ip_bans SET reason=?,updated_at=? WHERE id=?').bind(reason, now(), cur.id).run();
    await logActivity(DB, 'ip_ban_reason', `Edited ban reason for ${cur.ip}`);
    return json({ ok: true });
  }
  m = path.match(/^\/api\/admin\/ip-bans\/([A-Za-z0-9-]+)\/unban$/);
  if (m && method === 'POST') {
    const cur = await DB.prepare('SELECT * FROM ip_bans WHERE id=?').bind(m[1]).first();
    if (!cur) return json({ error: 'Ban record not found' }, 404);
    if (cur.status !== 'active') return json({ error: 'That IP address is not currently banned.' }, 409);
    await DB.prepare("UPDATE ip_bans SET status='unbanned',unbanned_at=?,unbanned_by='admin',updated_at=? WHERE id=?").bind(now(), now(), cur.id).run();
    await logActivity(DB, 'ip_unban', `Unbanned ${cur.ip}`);
    return json({ ok: true });
  }

  // ---- Live announcements
  if (path === '/api/admin/announcements' && method === 'GET') return json((await DB.prepare('SELECT * FROM announcements ORDER BY updated_at DESC').all()).results || []);
  if (path === '/api/admin/announcements' && method === 'POST') { const d = await body(request), message = clean(d.message, 240); if (!message) return json({ error: 'Announcement cannot be empty.' }, 400); const id = 'ANN-' + hex(crypto.getRandomValues(new Uint8Array(6))).toUpperCase(), t = now(); await DB.prepare('INSERT INTO announcements(id,message,active,created_at,updated_at) VALUES(?,?,?,?,?)').bind(id, message, d.active === false ? 0 : 1, t, t).run(); return json({ ok: true, id }); }
  let am = path.match(/^\/api\/admin\/announcements\/([A-Za-z0-9-]+)$/);
  if (am && method === 'PUT') { const d = await body(request), message = clean(d.message, 240); if (!message) return json({ error: 'Announcement cannot be empty.' }, 400); const r = await DB.prepare('UPDATE announcements SET message=?,active=?,updated_at=? WHERE id=?').bind(message, d.active === false ? 0 : 1, now(), am[1]).run(); return r.meta.changes ? json({ ok: true }) : json({ error: 'Announcement not found' }, 404); }
  if (am && method === 'DELETE') { const r = await DB.prepare('DELETE FROM announcements WHERE id=?').bind(am[1]).run(); return r.meta.changes ? json({ ok: true }) : json({ error: 'Announcement not found' }, 404); }

  // ---- Background music (admin only; every route below sits behind isAdmin + the CSRF header/Origin check)
  if (path === '/api/admin/music' && method === 'GET') return json(await musicState(DB));
  if (path === '/api/admin/music' && method === 'PUT') {
    const d = await body(request), cur = await musicState(DB);
    if (typeof d.enabled !== 'boolean') return json({ error: 'Enabled must be true or false.' }, 400);
    if (d.enabled && !cur.hasFile) return json({ error: 'Upload a music file before enabling background music.' }, 400);
    await upsert(DB, 'music_enabled', d.enabled ? '1' : '0').run();
    return json({ ok: true, ...(await musicState(DB)) });
  }
  if (path === '/api/admin/music/upload' && method === 'POST') {
    if (!env.MEDIA) return json({ error: 'R2 MEDIA bucket binding is missing.' }, 503);
    const bytes = await readCapped(request, MUSIC_MAX);
    if (!bytes) return json({ error: `Audio file must be ${MUSIC_MAX / 1048576} MB or smaller.` }, 413);
    if (!bytes.length) return json({ error: 'Choose an audio file first.' }, 400);
    let name = ''; try { name = decodeURIComponent(request.headers.get('x-file-name') || ''); } catch { /* bad encoding: fall back to default name */ }
    name = name.split(/[\\/]/).pop().replace(/[^\p{L}\p{N} ._()\[\]-]/gu, '_').trim().slice(0, 100) || 'music';
    const ext = ((name.match(/\.([A-Za-z0-9]+)$/) || [])[1] || '').toLowerCase(), kind = sniffAudio(bytes);
    if (!kind) return json({ error: 'That file is not a valid MP3, M4A/AAC, WAV or OGG audio file.' }, 400);
    if (!MUSIC_FORMATS[kind].ext.includes(ext)) return json({ error: `The file extension does not match its contents (detected: ${MUSIC_FORMATS[kind].label}).` }, 400);
    const fmt = MUSIC_FORMATS[kind], t = Date.now(), key = `xgencloud/music/${t}-${hex(crypto.getRandomValues(new Uint8Array(8)))}`;
    const old = (await DB.prepare("SELECT value FROM settings WHERE key='music_key'").first())?.value || '';
    await env.MEDIA.put(key, bytes, { httpMetadata: { contentType: fmt.type } });
    try {
      await DB.batch([['music_key', key], ['music_name', name], ['music_type', fmt.type], ['music_size', bytes.length], ['music_version', t], ['music_updated_at', now()]].map(([k, v]) => upsert(DB, k, v)));
    } catch (e) { await env.MEDIA.delete(key).catch(() => {}); throw e; }   // never leave an orphan file behind
    if (old && old !== key) await env.MEDIA.delete(old).catch(() => {});      // the new track replaces the previous one
    return json({ ok: true, ...(await musicState(DB)) });
  }
  if (path === '/api/admin/music/file' && method === 'GET') {   // admin preview of the saved track (works even while music is OFF)
    const row = await DB.prepare("SELECT value FROM settings WHERE key='music_key'").first();
    if (!row?.value || !env.MEDIA) return json({ error: 'No music uploaded yet.' }, 404);
    const type = (await DB.prepare("SELECT value FROM settings WHERE key='music_type'").first())?.value || 'audio/mpeg';
    let obj;
    try { obj = await env.MEDIA.get(row.value, { range: request.headers, onlyIf: request.headers }); }
    catch (e) { if (/range/i.test(String(e && e.message))) return new Response('Range not satisfiable', { status: 416 }); throw e; }
    if (!obj) return json({ error: 'Music file is missing from storage.' }, 404);
    const cr = contentRange(obj.range, obj.size);
    return new Response(obj.body || null, { status: !obj.body ? 304 : cr ? 206 : 200, headers: { 'content-type': type, 'accept-ranges': 'bytes', 'x-content-type-options': 'nosniff', 'cache-control': 'private, no-cache', etag: obj.httpEtag, ...(cr ? { 'content-range': cr } : {}) } });
  }
  // ---- Logo / background media management (site-wide branding)
  if (path === '/api/admin/media' && method === 'POST') {
    if (!env.MEDIA) return json({ error: 'R2 MEDIA bucket binding is missing.' }, 503);
    const d = await body(request), kind = ['logo', 'background', 'payment_qr'].includes(d.kind) ? d.kind : '';
    if (!kind || typeof d.dataUrl !== 'string') return json({ error: 'Choose a logo, background or payment QR image.' }, 400);
    const match = d.dataUrl.match(/^data:(image\/(?:png|jpeg|webp));base64,([A-Za-z0-9+/=]+)$/); if (!match) return json({ error: 'Only PNG, JPG and WebP images are allowed.' }, 400);
    const bytes = Uint8Array.from(atob(match[2]), c => c.charCodeAt(0)); if (bytes.length > 2 * 1024 * 1024) return json({ error: 'Image must be 2 MB or smaller.' }, 413);
    if (sniffImage(bytes) !== match[1]) return json({ error: 'The uploaded file is not a valid PNG, JPG or WebP image.' }, 400);
    const old = await DB.prepare('SELECT value FROM settings WHERE key=?').bind(`${kind}_key`).first(); const key = `xgencloud/${kind}/${Date.now()}-${hex(crypto.getRandomValues(new Uint8Array(8)))}`; await env.MEDIA.put(key, bytes, { httpMetadata: { contentType: match[1] } });
    await DB.prepare('INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value').bind(`${kind}_key`, key).run(); if (old?.value) await env.MEDIA.delete(old.value);
    if (kind === 'payment_qr') { await upsert(DB, 'payment_qr_version', Date.now()).run(); await logActivity(DB, 'settings_payment_qr', 'Updated the payment QR code image'); }
    return json({ ok: true, key });
  }
  if (path === '/api/admin/media' && method === 'DELETE') {
    const kind = new URL(request.url).searchParams.get('kind'); if (!['logo', 'background', 'payment_qr'].includes(kind)) return json({ error: 'Invalid image type.' }, 400);
    const row = await DB.prepare('SELECT value FROM settings WHERE key=?').bind(`${kind}_key`).first(); if (row?.value && env.MEDIA) await env.MEDIA.delete(row.value);
    await DB.prepare("INSERT INTO settings(key,value) VALUES(?,'') ON CONFLICT(key) DO UPDATE SET value=''").bind(`${kind}_key`).run();
    if (kind === 'payment_qr') { await upsert(DB, 'payment_qr_version', '').run(); await logActivity(DB, 'settings_payment_qr', 'Removed the payment QR code image (the shop shows the built-in QR again)'); }
    return json({ ok: true });
  }
  // ---- Store settings (UPI ID, legacy banner, Discord invite)
  if (path === '/api/admin/settings' && method === 'GET') {
    const { results = [] } = await DB.prepare("SELECT key,value FROM settings WHERE key IN ('upi_id','banner','logo_key','background_key','discord_invite','payment_qr_key','payment_qr_version')").all();
    return json(Object.fromEntries(results.map(r => [r.key, r.value])));
  }
  if (path === '/api/admin/settings' && method === 'PUT') {
    const d = await body(request);
    for (const [k, v, max] of [['upi_id', d.upi_id, 100], ['banner', d.banner, 160]])
      await DB.prepare('INSERT INTO settings (key,value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value').bind(k, clean(v, max)).run();
    if (d.discord_invite !== undefined) {
      const invite = clean(d.discord_invite, 200);
      if (!DISCORD_RE.test(invite)) return json({ error: 'Enter a valid Discord invite link, e.g. https://discord.gg/XXXXX' }, 400);
      await upsert(DB, 'discord_invite', invite).run();
      await logActivity(DB, 'settings_discord', 'Updated the Discord invite link');
    }
    return json({ ok: true });
  }
  return json({ error: 'Not found' }, 404);
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname === '/media/payment-qr') { try { const row = await env.DB.prepare("SELECT value FROM settings WHERE key='payment_qr_key'").first(); if (!row?.value || !env.MEDIA) return new Response('Not found', { status: 404 }); const obj = await env.MEDIA.get(row.value); if (!obj) return new Response('Not found', { status: 404 }); const h = new Headers(); obj.writeHttpMetadata(h); h.set('cache-control', 'private, no-cache'); h.set('x-content-type-options', 'nosniff'); return new Response(obj.body, { headers: h }) } catch { return new Response('Not found', { status: 404 }) } }
    if (url.pathname === '/media/logo' || url.pathname === '/media/background') { try { const kind = url.pathname.endsWith('/logo') ? 'logo' : 'background'; const row = await env.DB.prepare('SELECT value FROM settings WHERE key=?').bind(`${kind}_key`).first(); if (!row?.value || !env.MEDIA) return new Response('Not found', { status: 404 }); const obj = await env.MEDIA.get(row.value); if (!obj) return new Response('Not found', { status: 404 }); const h = new Headers(); obj.writeHttpMetadata(h); h.set('cache-control', 'public,max-age=300'); return new Response(obj.body, { headers: h }) } catch { return new Response('Not found', { status: 404 }) } }
    const imgMatch = url.pathname.match(/^\/media\/img\/(.+)$/);
    if (imgMatch) {
      try {
        const key = decodeURIComponent(imgMatch[1]);
        if (!env.MEDIA || !/^xgencloud\/images\/[A-Za-z0-9._-]+$/.test(key)) return new Response('Not found', { status: 404 });
        const obj = await env.MEDIA.get(key);
        if (!obj) return new Response('Not found', { status: 404 });
        const h = new Headers(); obj.writeHttpMetadata(h); h.set('cache-control', 'private,max-age=300'); h.set('x-content-type-options', 'nosniff');
        return new Response(obj.body, { headers: h });
      } catch { return new Response('Not found', { status: 404 }) }
    }
    if (url.pathname.startsWith('/api/')) {
      try { return await api(request, env); } catch (e) { console.error(e); return json({ error: 'Server error' }, 500); }
    }
    return env.ASSETS.fetch(request);
  }
};
