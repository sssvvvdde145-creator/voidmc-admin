# XgenCloud Admin Panel — Cloudflare Workers + D1

```
shop package  -> shop.xgencloud.bond   public hosting store + public API (NO admin code at all)
this package  -> admin.xgencloud.bond  admin dashboard + admin API (separate Worker)
Both Workers use the SAME D1 database (void-mc-store-db) and the SAME R2 bucket (voidmc-media),
so categories, products, prices, UPI ID, Discord invite, orders, payment codes, coupons,
announcements, music and branding edited here appear live on the store.
```

## Deploy / upgrade (run each command from this `admin` folder)
1. `npm install && npx wrangler login`
2. The D1 database ID is already set and matches the shop package. Do NOT create a new database — all existing customer, order and payment data is preserved.
3. Apply the new migration from the **shop package** (it owns the migrations folder):
   ```bash
   cd ../shop-package-folder && npx wrangler d1 migrations apply void-mc-store-db --remote
   ```
   (Tables are also self-healed on first request, so nothing breaks if the migration runs later.)
4. Secrets (typed into the terminal prompt, never into any file):
   - `npx wrangler secret put ADMIN_PASSWORD` → enter `XGEN-ADMIN` (the initial password)
   - `npx wrangler secret put SESSION_SECRET` → a long random string (32+ chars), different from the password
   - Keep the SAME `SESSION_SECRET` value the admin Worker already has; changing it only logs out existing sessions.
5. `npm run deploy` — `wrangler.jsonc` already declares the `admin.xgencloud.bond` custom domain, so it attaches automatically (zone must be in the same Cloudflare account). Remove the old `admin.voidmc.bond` domain when ready.

## First login and password
- Sign in at `https://admin.xgencloud.bond` with the initial password `XGEN-ADMIN`.
- On first login, the password is stored as a PBKDF2-SHA256 hash in D1 (never plain text, never in code).
- Change it immediately in **Admin → Branding → Change admin password**. After that the Worker secret is no longer used.
- Sessions: HttpOnly + Secure + SameSite=Strict `__Host-` cookie, 8h expiry, CSRF header + Origin check, 5 failed attempts = 15-minute lockout.

## What this panel manages
- **Overview** — order stats, category/product/ban counts, recent admin activity.
- **Verify Payment Code** — accepts new `XG…CL` codes and legacy `VM…HE` codes.
- **Orders** — full order history (historical VOID MC orders included), verify/reject, delete.
- **Categories** — unlimited main categories and subcategories: create, edit name/description, upload/preview/remove images, enable/disable, display order, delete (blocked while products or subcategories still use it). The shop menu updates automatically.
- **Products** — create/edit/delete hosting products: name, description, specifications, monthly/quarterly/yearly prices, image, category + subcategory, stock (-1 = unlimited), enable/disable, featured flag, display order.
- **IP Bans** — ban/unban IP addresses with confirmation, reasons (editable), search and status filter, full ban/unban history in the activity log. Active bans are enforced server-side on the shop's checkout endpoints using Cloudflare's `CF-Connecting-IP` only; the admin panel itself stays accessible.
- **Coupons, Announcements, Music, Maintenance** — unchanged.
- **Branding** — logo, background, payment QR code (upload / change / remove; stored in R2 and shown at checkout, with the shop falling back to its built-in QR when none is uploaded; every change is recorded in the activity log), UPI ID, the Discord invite link (default `https://discord.gg/kBHUk8FcB`), and the admin password change form.

## Notes
- A payment code proves the customer pressed the button, NOT that money arrived. Always match the amount in your UPI/bank app before pressing "Mark payment verified".
- The old Ranks and Free Rank tabs were removed. Historical orders, customer records, coupons and free-rank claim data remain in the database untouched.
- The Worker name stays `void-mc-admin` and the bucket stays `voidmc-media` so the existing deployment and bindings are preserved; only the public hostname changes.

## Local development
Copy `.dev.vars.example` to `.dev.vars`, then `npm install && npm run dev`. Local D1 is separate from the remote database.


## Footer credit update
- Panel footer displays `Made by HzardExecx!` (version 4.0.1).
