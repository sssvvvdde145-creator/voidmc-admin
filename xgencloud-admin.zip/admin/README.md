# XgenCloud Admin Panel — Cloudflare Workers + D1

```
shop package  -> shop.xgencloud.bond   public hosting store + public API (NO admin code at all)
this package  -> admin.xgencloud.bond  admin dashboard + admin API (separate Worker)
Both Workers use the SAME D1 database (xgencloud-store-db) and the SAME R2 bucket (xgencloud-media),
so categories, products, prices, UPI ID, Discord invite, orders, payment codes, coupons,
announcements, music and branding edited here appear live on the store.
```

## Deploy / upgrade (run each command from this `admin` folder)
1. `npm install && npx wrangler login`
2. The D1 database ID placeholder in `wrangler.jsonc` must be replaced with the ID of the shared `xgencloud-store-db` database (same ID as in the shop package). Do NOT create a second database — all existing customer, order and payment data lives in the one shared database. If you are moving from the old VOID MC resources, the shop package's `MIGRATE-STEPS.txt` creates the new database, prints its ID and copies all data over.
3. Apply the new migration from the **shop package** (it owns the migrations folder):
   ```bash
   cd ../shop-package-folder && npx wrangler d1 migrations apply xgencloud-store-db --remote
   ```
   (Tables are also self-healed on first request, so nothing breaks if the migration runs later.)
4. Secrets (typed into the terminal prompt, never into any file):
   - `npx wrangler secret put ADMIN_PASSWORD` → enter `XGEN-ADMIN` (the initial password)
   - `npx wrangler secret put SESSION_SECRET` → a long random string (32+ chars), different from the password
   - Keep the SAME `SESSION_SECRET` value the admin Worker already has; changing it only logs out existing sessions.
5. `npm run deploy` — `wrangler.jsonc` already declares the `admin.xgencloud.bond` custom domain, so it attaches automatically (zone must be in the same Cloudflare account). Remove the old `admin.voidmc.bond` domain when ready.

## First login and password
- Sign in at `https://admin.xgencloud.bond` with the initial password `XGEN-ADMIN`.
- On first login, the password is stored as a PBKDF2-SHA256 hash in D1 (never plain text, never in code).
- Change it immediately in **Admin → Branding → Change admin password**. After that the Worker secret is no longer used.
- Sessions: HttpOnly + Secure + SameSite=Strict `__Host-` cookie, 8h expiry, CSRF header + Origin check, 5 failed attempts = 15-minute lockout.

## What this panel manages
- **Overview** — order stats, category/product/ban counts, recent admin activity.
- **Verify Payment Code** — accepts new `XG…CL` codes and legacy `VM…HE` codes.
- **Orders** — full order history (historical VOID MC orders included), verify/reject, delete.
- **Categories** — unlimited main categories and subcategories: create, edit name/description, upload/preview/remove images, enable/disable, display order, delete (blocked while products or subcategories still use it). The shop menu updates automatically.
- **Products** — create/edit/delete hosting products: name, description, specifications, monthly/quarterly/yearly prices, image, category + subcategory, stock (-1 = unlimited), enable/disable, featured flag, display order.
- **IP Bans** — ban/unban IP addresses with confirmation, reasons (editable), search and status filter, full ban/unban history in the activity log. Active bans are enforced server-side on the shop's checkout endpoints using Cloudflare's `CF-Connecting-IP` only; the admin panel itself stays accessible.
- **Coupons, Announcements, Music, Maintenance** — unchanged.
- **Branding** — logo, background, payment QR code (upload / change / remove; stored in R2 and shown at checkout, with the shop falling back to its built-in QR when none is uploaded; every change is recorded in the activity log), UPI ID, the Discord invite link (default `https://discord.gg/kBHUk8FcB`), and the admin password change form.

## Notes
- A payment code proves the customer pressed the button, NOT that money arrived. Always match the amount in your UPI/bank app before pressing "Mark payment verified".
- The old Ranks and Free Rank tabs were removed. Historical orders, customer records, coupons and free-rank claim data remain in the database untouched.
- The Worker name stays `void-mc-admin` so the existing deployment is preserved; only the public hostname changed earlier. The D1 database and R2 bucket are now named `xgencloud-store-db` and `xgencloud-media`. If your data still lives in the old VOID MC resources, run the shop package's `MIGRATE-STEPS.txt` once (the database is shared) before deploying.

## Local development
Copy `.dev.vars.example` to `.dev.vars`, then `npm install && npm run dev`. Local D1 is separate from the remote database.


## Footer credit update
- Panel footer displays `Made by HzardExecx!` (version 4.0.1).

## Automatic deploys with GitHub Actions

The workflow at `.github/workflows/deploy.yml` deploys this Worker on every push to `main`. It runs `npm install` and this package's existing `npm run deploy` script from the repository root. You can also start it manually from GitHub Actions with **Run workflow**.

One-time setup for each GitHub repository:
1. In Cloudflare, create an API token using the **Edit Cloudflare Workers** template. Limit it to the account that owns `void-mc-admin`, and include the relevant zone access if Cloudflare requests it for the configured custom domain.
2. In the GitHub repository, open **Settings → Secrets and variables → Actions → New repository secret**. Add `CLOUDFLARE_API_TOKEN` with the token value and `CLOUDFLARE_ACCOUNT_ID` with the Cloudflare account ID.
3. Keep both values in GitHub Secrets only. Do not commit them to the repository. Push to `main` to deploy.

This repo's root must be this package directory, containing `package.json` and `wrangler.jsonc`. Before deploying, the workflow also creates the `xgencloud-media` R2 bucket if it is missing and applies D1 migrations when this repository contains migration files (normally the shop package owns migrations, so this step usually just logs a skip). After deploying, it re-sets the `ADMIN_PASSWORD` and `SESSION_SECRET` Worker secrets from GitHub repository secrets of the same names, so add those two repository secrets alongside `CLOUDFLARE_API_TOKEN` and `CLOUDFLARE_ACCOUNT_ID`.
