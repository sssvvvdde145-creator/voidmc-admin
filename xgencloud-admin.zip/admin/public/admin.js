const $=s=>document.querySelector(s);
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const money=n=>'₹'+Number(n||0).toLocaleString('en-IN');
const toast=t=>{const e=$('#toast');e.textContent=t;e.classList.add('show');setTimeout(()=>e.classList.remove('show'),2400)};
async function api(path,method='GET',data){
  const r=await fetch('/api/admin/'+path,{method,headers:{'Content-Type':'application/json','X-XGEN-Admin':'1'},body:data?JSON.stringify(data):undefined});
  const d=await r.json().catch(()=>({}));
  if(r.status===401&&path!=='login'){lock();throw Error('Session expired. Please sign in again.')}
  if(!r.ok)throw Error(d.error||'Request failed');return d;
}
const lock=()=>{$('#app').hidden=true;$('#login').hidden=false};
const unlock=()=>{$('#login').hidden=true;$('#app').hidden=false;go('overview')};
const tag=s=>`<span class="tag ${esc(s)}">${esc(String(s).replace('_',' ').toUpperCase())}</span>`;
const items=o=>o.items.map(i=>`${esc(i.name)}${i.period?' ('+esc(i.period)+')':''} ×${i.qty}`).join(', ');
const run=fn=>async(...a)=>{try{await fn(...a)}catch(e){toast(e.message)}};
const fmtD=t=>t?new Date(t).toLocaleString():'-';
const readImage=f=>new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(r.result);r.onerror=reject;r.readAsDataURL(f)});
const imgOk=f=>{if(!f)return'Choose an image first';if(!/^image\/(png|jpeg|webp)$/.test(f.type))return'Only PNG, JPG or WebP images';if(f.size>2*1024*1024)return'Image must be 2 MB or smaller';return''};
let tab='overview',musicPreviewUrl='';
function go(t){tab=t;document.querySelectorAll('#nav button').forEach(b=>b.classList.toggle('on',b.dataset.tab===t));views[t]().catch(e=>toast(e.message))}
function set(html){$('#view').innerHTML=html}
function orderCard(o){return `<div class="row"><div><b>${esc(o.id)}</b> · ${esc(o.customer_name)} ${tag(o.status)}<br><span class="muted">${items(o)} · ${money(o.total)}${o.coupon?' · coupon '+esc(o.coupon):''}<br>${esc(o.email)} · ${esc(o.phone)} · ${esc(o.location)}${o.minecraft_username?`<br>Username: <b>${esc(o.minecraft_username)}</b>`:''}<br>${esc(fmtD(o.created_at))}</span>${o.code?`<br><span class="code">${esc(o.code)}</span>`:''}</div></div>`}
function bindStatus(){document.querySelectorAll('[data-st]').forEach(b=>b.onclick=run(async()=>{await api(`orders/${b.dataset.id}/status`,'POST',{status:b.dataset.st});toast('Order '+b.dataset.st);go(tab)}))}
const views={
async overview(){const s=await api('stats'),by=Object.fromEntries(s.byStatus.map(x=>[x.status,x]));const g=k=>by[k]||{n:0,s:0};
  set(`<h2>Overview</h2>${s.maintenance?'<div class="maint-banner">🛠 MAINTENANCE MODE IS ON — the shop is closed to customers. <button class="sm" data-goto="maintenance">Manage</button></div>':''}<div class="grid"><div class="stat">Awaiting payment<b>${g('awaiting_payment').n}</b></div><div class="stat">Codes to verify<b>${g('payment_submitted').n}</b></div><div class="stat">Verified orders<b>${g('verified').n}</b></div><div class="stat">Verified revenue<b>${money(g('verified').s)}</b></div><div class="stat">Categories<b>${s.categories}</b></div><div class="stat">Products<b>${s.products}</b></div><div class="stat">Active coupons<b>${s.activeCoupons}</b></div><div class="stat">Banned IPs<b>${s.bannedIps}</b></div></div>
  <div class="panel spaced"><h3>Recent activity</h3><div id="activity-list"><p class="muted">Loading…</p></div></div>`);
  document.querySelectorAll('[data-goto]').forEach(b=>b.onclick=()=>go(b.dataset.goto));
  try{const acts=await api('activity');$('#activity-list').innerHTML=acts.slice(0,15).map(a=>`<div class="row"><div><b>${esc(a.action)}</b> <span class="muted">${esc(a.detail)}</span><br><span class="muted">${esc(a.actor)} · ${esc(fmtD(a.created_at))}</span></div></div>`).join('')||'<p class="muted">No activity recorded yet.</p>'}catch{$('#activity-list').innerHTML='<p class="muted">Activity log unavailable.</p>'}},
async verify(){set(`<h2>Verify Payment Code</h2><div class="panel"><div class="form"><input id="vc" maxlength="20" placeholder="XG••••••••••••••••CL" autocomplete="off"><button class="btn" id="vb">Verify</button></div><div id="vr"></div></div>`);
  const check=run(async()=>{const d=await api('verify','POST',{code:$('#vc').value});
    $('#vr').innerHTML=d.valid?`<div class="result ok"><h3>✅ VALID CODE</h3>${orderCard(d)}<div class="form"><button class="sm" data-st="verified" data-id="${esc(d.id)}">Mark payment verified</button><button class="sm red" data-st="rejected" data-id="${esc(d.id)}">Reject</button></div></div>`:'<div class="result bad"><h3>❌ INVALID CODE</h3><span class="muted">No order matches this code.</span></div>';bindStatus()});
  $('#vb').onclick=check;$('#vc').onkeydown=e=>{if(e.key==='Enter')check()}},
async orders(){const rows=await api('orders');set(`<h2>Orders</h2><div class="panel">${rows.map(o=>`${orderCard(o)}<div class="form order-actions">${o.code&&o.status!=='verified'&&o.status!=='rejected'?`<button class="sm" data-st="verified" data-id="${esc(o.id)}">Verify</button><button class="sm red" data-st="rejected" data-id="${esc(o.id)}">Reject</button>`:''}<button class="sm red" data-order-delete="${esc(o.id)}">Delete order</button></div>`).join('')||'<p class="muted">No orders yet.</p>'}</div>`);bindStatus();document.querySelectorAll('[data-order-delete]').forEach(b=>b.onclick=run(async()=>{if(confirm('Permanently delete order '+b.dataset.orderDelete+'?')){await api('orders/'+b.dataset.orderDelete,'DELETE');toast('Order deleted');go('orders')}}))},
async categories(){const rows=await api('shop-categories');
  const mains=rows.filter(c=>!c.parent_id),subsOf=id=>rows.filter(c=>c.parent_id===id);
  const mainOpts=mains.map(c=>`<option value="${esc(c.id)}">${esc(c.name)}</option>`).join('');
  const catCard=c=>`<div class="cat-card" data-cat="${esc(c.id)}">
    <div class="cat-top">${c.image_key?`<img class="cat-img" src="/media/img/${esc(c.image_key)}" alt="">`:'<div class="cat-img cat-ph">🗂️</div>'}
    <div class="cat-meta"><b>${esc(c.name)}</b>${c.parent_id?'':''}<br><span class="muted">Sort ${c.sort} · ${c.enabled?'Enabled':'Disabled'}${c.description?'<br>'+esc(c.description):''}</span></div>
    <span class="tag ${c.enabled?'verified':'rejected'}">${c.enabled?'ENABLED':'DISABLED'}</span></div>
    <div class="fields"><label>Name<input data-f="name" maxlength="40" value="${esc(c.name)}"></label><label>Display order<input data-f="sort" type="number" step="1" value="${c.sort}"></label><label class="wide">Description<input data-f="description" maxlength="200" value="${esc(c.description)}"></label></div>
    <div class="form"><button class="sm" data-save>Save</button><button class="sm ghost" data-toggle>${c.enabled?'Disable':'Enable'}</button><button class="sm red" data-del>Delete</button></div>
    <div class="form img-row"><input type="file" data-imgfile accept="image/png,image/jpeg,image/webp"><button class="sm" data-imgup>Upload / change image</button>${c.image_key?'<button class="sm red" data-imgrm>Remove image</button>':''}</div></div>`;
  set(`<h2>Categories</h2><p class="muted">Main categories and subcategories appear on the shop and in the hamburger menu automatically. Nothing here requires code changes.</p>
  <div class="panel"><h3>Create main category</h3><div class="form"><input id="nc-name" maxlength="40" placeholder="e.g. Minecraft Hosting"><input id="nc-sort" type="number" step="1" placeholder="Order (0)"><button class="btn" id="nc-create">Create</button></div>
  <h3>Create subcategory</h3><div class="form"><select id="sc-parent">${mainOpts||'<option value="">Create a main category first</option>'}</select><input id="sc-name" maxlength="40" placeholder="e.g. Budget Hosting"><button class="btn ghost" id="sc-create">Create subcategory</button></div></div>
  ${mains.map(c=>catCard(c)+(subsOf(c.id).length?`<div class="sub-list">${subsOf(c.id).map(catCard).join('')}</div>`:'')).join('')||'<p class="muted">No categories yet. Create your first main category above.</p>'}`);
  $('#nc-create').onclick=run(async()=>{await api('shop-categories','POST',{name:$('#nc-name').value,sort:Number($('#nc-sort').value)||0});toast('Category created');go('categories')});
  $('#sc-create').onclick=run(async()=>{if(!$('#sc-parent').value)throw Error('Create a main category first');await api('shop-categories','POST',{name:$('#sc-name').value,parentId:$('#sc-parent').value});toast('Subcategory created');go('categories')});
  document.querySelectorAll('[data-cat]').forEach(el=>{const id=el.dataset.cat,cur=rows.find(c=>c.id===id);
    const read=()=>({name:el.querySelector('[data-f=name]').value,description:el.querySelector('[data-f=description]').value,sort:Number(el.querySelector('[data-f=sort]').value)||0});
    el.querySelector('[data-save]').onclick=run(async()=>{await api('shop-categories/'+id,'PUT',read());toast('Category saved');go('categories')});
    el.querySelector('[data-toggle]').onclick=run(async()=>{await api('shop-categories/'+id,'PUT',{enabled:!cur.enabled});go('categories')});
    el.querySelector('[data-del]').onclick=run(async()=>{if(confirm('Delete category "'+cur.name+'"?')){await api('shop-categories/'+id,'DELETE');toast('Category deleted');go('categories')}});
    el.querySelector('[data-imgup]').onclick=run(async()=>{const f=el.querySelector('[data-imgfile]').files[0];const err=imgOk(f);if(err)throw Error(err);await api('shop-categories/'+id+'/image','PUT',{dataUrl:await readImage(f)});toast('Image updated');go('categories')});
    const rm=el.querySelector('[data-imgrm]');if(rm)rm.onclick=run(async()=>{if(confirm('Remove this category image?')){await api('shop-categories/'+id+'/image','PUT',{remove:true});go('categories')}})})},
async products(){const [rows,cats]=await Promise.all([api('products'),api('shop-categories')]);
  const mains=cats.filter(c=>!c.parent_id),subs=cats.filter(c=>c.parent_id);
  const catName=id=>(cats.find(c=>c.id===id)||{}).name||'';
  set(`<h2>Products</h2><p class="muted">Hosting products appear on the shop as soon as they are enabled. Set 0 for a billing period you do not offer.</p>
  <div class="panel"><h3 id="pf-title">Create product</h3><input type="hidden" id="pf-id">
  <div class="fields"><label>Name<input id="pf-name" maxlength="60" placeholder="e.g. Budget Minecraft 2GB"></label><label>Display order<input id="pf-sort" type="number" step="1" value="0"></label>
  <label>Monthly price (₹)<input id="pf-pm" type="number" min="0" step="1" value="0"></label><label>Quarterly price (₹)<input id="pf-pq" type="number" min="0" step="1" value="0"></label><label>Yearly price (₹)<input id="pf-py" type="number" min="0" step="1" value="0"></label>
  <label>Category<select id="pf-cat"><option value="">None</option>${mains.map(c=>`<option value="${esc(c.id)}">${esc(c.name)}</option>`).join('')}</select></label><label>Subcategory<select id="pf-sub"><option value="">None</option></select></label>
  <label>Stock (-1 = unlimited)<input id="pf-stock" type="number" step="1" value="-1"></label>
  <label class="wide">Description<input id="pf-desc" maxlength="500" placeholder="Short sales description"></label>
  <label class="wide">Specifications (one per line)<textarea id="pf-specs" maxlength="1000" placeholder="2 GB RAM&#10;NVMe SSD&#10;DDoS protection"></textarea></label>
  <label class="check"><input id="pf-enabled" type="checkbox" checked> Enabled (visible on shop)</label><label class="check"><input id="pf-featured" type="checkbox"> Featured</label></div>
  <button class="btn" id="pf-save">Create product</button> <button class="btn ghost" id="pf-reset" hidden>Cancel edit</button></div>
  <div class="panel spaced"><h3>All products (${rows.length})</h3>${rows.map(p=>`<div class="prod-row"><div><b>${esc(p.name)}</b> ${p.featured?'<span class="tag verified">FEATURED</span>':''} ${tag(p.enabled?'verified':'rejected').replace(/VERIFIED|REJECTED/,p.enabled?'ENABLED':'DISABLED')}<br><span class="muted">${esc(catName(p.category_id))}${p.subcategory_id?' › '+esc(catName(p.subcategory_id)):''} · ${money(p.price_monthly)}/mo${p.price_quarterly?' · '+money(p.price_quarterly)+'/qtr':''}${p.price_yearly?' · '+money(p.price_yearly)+'/yr':''} · stock ${p.stock===-1?'∞':p.stock} · sort ${p.sort}</span></div>
  <div class="form"><button class="sm" data-edit="${esc(p.id)}">Edit</button><button class="sm ghost" data-pimg="${esc(p.id)}">Image</button><button class="sm ghost" data-ptoggle="${esc(p.id)}">${p.enabled?'Disable':'Enable'}</button><button class="sm red" data-pdel="${esc(p.id)}">Delete</button></div></div>`).join('')||'<p class="muted">No products yet.</p>'}</div>`);
  const subOpts=pid=>subs.filter(s=>s.parent_id===pid).map(s=>`<option value="${esc(s.id)}">${esc(s.name)}</option>`).join('');
  const syncSubs=()=>{$('#pf-sub').innerHTML='<option value="">None</option>'+subOpts($('#pf-cat').value)};
  $('#pf-cat').onchange=syncSubs;
  const clearForm=()=>{$('#pf-id').value='';$('#pf-title').textContent='Create product';$('#pf-save').textContent='Create product';['pf-name','pf-desc','pf-specs'].forEach(i=>$('#'+i).value='');['pf-pm','pf-pq','pf-py'].forEach(i=>$('#'+i).value='0');$('#pf-stock').value='-1';$('#pf-sort').value='0';$('#pf-cat').value='';syncSubs();$('#pf-enabled').checked=true;$('#pf-featured').checked=false;$('#pf-reset').hidden=true};
  const readForm=()=>({name:$('#pf-name').value,description:$('#pf-desc').value,specs:$('#pf-specs').value,price_monthly:Number($('#pf-pm').value),price_quarterly:Number($('#pf-pq').value),price_yearly:Number($('#pf-py').value),category_id:$('#pf-cat').value,subcategory_id:$('#pf-sub').value,stock:Number($('#pf-stock').value),enabled:$('#pf-enabled').checked,featured:$('#pf-featured').checked,sort:Number($('#pf-sort').value)||0});
  $('#pf-save').onclick=run(async()=>{const id=$('#pf-id').value;if(id){await api('products/'+id,'PUT',readForm());toast('Product saved')}else{await api('products','POST',readForm());toast('Product created')}go('products')});
  $('#pf-reset').onclick=clearForm;
  document.querySelectorAll('[data-edit]').forEach(b=>b.onclick=()=>{const p=rows.find(x=>x.id===b.dataset.edit);if(!p)return;
    $('#pf-id').value=p.id;$('#pf-title').textContent='Edit: '+p.name;$('#pf-save').textContent='Save changes';$('#pf-name').value=p.name;$('#pf-desc').value=p.description;$('#pf-specs').value=p.specs;$('#pf-pm').value=p.price_monthly;$('#pf-pq').value=p.price_quarterly;$('#pf-py').value=p.price_yearly;$('#pf-stock').value=p.stock;$('#pf-sort').value=p.sort;$('#pf-cat').value=p.category_id||'';syncSubs();$('#pf-sub').value=p.subcategory_id||'';$('#pf-enabled').checked=!!p.enabled;$('#pf-featured').checked=!!p.featured;$('#pf-reset').hidden=false;scrollTo({top:0,behavior:'smooth'})});
  document.querySelectorAll('[data-ptoggle]').forEach(b=>b.onclick=run(async()=>{const p=rows.find(x=>x.id===b.dataset.ptoggle);await api('products/'+p.id,'PUT',{enabled:!p.enabled});go('products')}));
  document.querySelectorAll('[data-pdel]').forEach(b=>b.onclick=run(async()=>{const p=rows.find(x=>x.id===b.dataset.pdel);if(confirm('Delete product "'+p.name+'"? Past orders keep their own copy.')){await api('products/'+p.id,'DELETE');toast('Product deleted');go('products')}}));
  document.querySelectorAll('[data-pimg]').forEach(b=>b.onclick=()=>{const p=rows.find(x=>x.id===b.dataset.pimg);const host=b.closest('.prod-row');const old=host.querySelector('.img-editor');if(old){old.remove();return}
    host.insertAdjacentHTML('beforeend',`<div class="img-editor form">${p.image_key?`<img class="media-preview" src="/media/img/${esc(p.image_key)}" alt="Product image">`:'<span class="muted">No image</span>'}<input type="file" accept="image/png,image/jpeg,image/webp" data-pif><button class="sm" data-piup>Upload / change</button>${p.image_key?'<button class="sm red" data-pirm>Remove</button>':''}</div>`);
    host.querySelector('[data-piup]').onclick=run(async()=>{const f=host.querySelector('[data-pif]').files[0];const err=imgOk(f);if(err)throw Error(err);await api('products/'+p.id+'/image','PUT',{dataUrl:await readImage(f)});toast('Image updated');go('products')});
    const rm=host.querySelector('[data-pirm]');if(rm)rm.onclick=run(async()=>{if(confirm('Remove this product image?')){await api('products/'+p.id+'/image','PUT',{remove:true});go('products')}})})},
async ipbans(){set(`<h2>IP Ban / Unban</h2><p class="muted">Banned IPs cannot use checkout or submit orders. The Admin Panel always stays accessible. Bans apply server-side using Cloudflare's trusted client IP.</p>
  <div class="panel"><h3>Ban an IP address</h3><div class="form"><input id="ban-ip" maxlength="45" placeholder="e.g. 203.0.113.10"><input id="ban-reason" maxlength="200" placeholder="Reason (optional)"><button class="btn red-bg" id="ban-add">Ban IP</button></div></div>
  <div class="panel spaced"><h3>Ban records</h3><div class="form"><input id="ban-q" placeholder="Search IP or reason"><select id="ban-status"><option value="">All statuses</option><option value="active">Active</option><option value="unbanned">Unbanned</option></select><button class="btn ghost" id="ban-search">Search</button></div><div id="ban-list"><p class="muted">Loading…</p></div></div>
  <div class="panel spaced"><h3>Ban / unban history</h3><div id="ban-log"><p class="muted">Loading…</p></div></div>`);
  const load=run(async()=>{const q=encodeURIComponent($('#ban-q').value.trim()),st=$('#ban-status').value;
    const rows=await api('ip-bans'+(q||st?`?${q?'q='+q:''}${q&&st?'&':''}${st?'status='+st:''}`:''));
    $('#ban-list').innerHTML=rows.map(b=>`<div class="row"><div><b class="code">${esc(b.ip)}</b> ${tag(b.status==='active'?'rejected':'verified').replace(/REJECTED|VERIFIED/,b.status==='active'?'ACTIVE BAN':'UNBANNED')}<br><span class="muted">${b.reason?'Reason: '+esc(b.reason)+'<br>':''}Banned ${esc(fmtD(b.created_at))} by ${esc(b.banned_by)}${b.status==='unbanned'?`<br>Unbanned ${esc(fmtD(b.unbanned_at))} by ${esc(b.unbanned_by)}`:''}</span></div>
    <div>${b.status==='active'?`<button class="sm" data-unban="${esc(b.id)}" data-ip="${esc(b.ip)}">Unban</button> `:''}<button class="sm ghost" data-reason="${esc(b.id)}" data-ip="${esc(b.ip)}" data-cur="${esc(b.reason)}">Edit reason</button></div></div>`).join('')||'<p class="muted">No matching ban records.</p>';
    document.querySelectorAll('[data-unban]').forEach(btn=>btn.onclick=run(async()=>{if(confirm('Unban '+btn.dataset.ip+'? They will be able to order again.')){await api('ip-bans/'+btn.dataset.unban+'/unban','POST');toast('IP unbanned');load();loadLog()}}));
    document.querySelectorAll('[data-reason]').forEach(btn=>btn.onclick=run(async()=>{const reason=prompt('Ban reason for '+btn.dataset.ip,btn.dataset.cur||'');if(reason===null)return;await api('ip-bans/'+btn.dataset.reason,'PUT',{reason});toast('Reason saved');load();loadLog()}))});
  const loadLog=run(async()=>{const acts=(await api('activity')).filter(a=>a.action.startsWith('ip_'));
    $('#ban-log').innerHTML=acts.map(a=>`<div class="row"><div><b>${esc(a.action==='ip_ban'?'BANNED':a.action==='ip_unban'?'UNBANNED':'EDITED')}</b> <span class="muted">${esc(a.detail)}</span><br><span class="muted">${esc(a.actor)} · ${esc(fmtD(a.created_at))}</span></div></div>`).join('')||'<p class="muted">No ban activity yet.</p>'});
  $('#ban-add').onclick=run(async()=>{const ip=$('#ban-ip').value.trim();if(!ip)throw Error('Enter an IP address');if(!confirm('Ban '+ip+'? They will be blocked from checkout immediately.'))return;await api('ip-bans','POST',{ip,reason:$('#ban-reason').value});toast('IP banned');$('#ban-ip').value='';$('#ban-reason').value='';load();loadLog()});
  $('#ban-search').onclick=load;$('#ban-q').onkeydown=e=>{if(e.key==='Enter')load()};$('#ban-status').onchange=load;
  load();loadLog()},
async coupons(){const rows=await api('coupons');
  set(`<h2>Coupons</h2><div class="panel"><h3>Random coupon</h3><div class="form"><input id="rp" type="number" min="1" max="90" placeholder="Discount %"><button class="btn" id="rb">Generate random (6 chars)</button></div><h3>Custom coupon</h3><div class="form"><input id="cc" maxlength="6" placeholder="6-character code"><input id="cp" type="number" min="1" max="90" placeholder="Discount %"><button class="btn ghost" id="cb">Create</button></div>${rows.map(c=>`<div class="row"><div><b class="code">${esc(c.code)}</b> · ${c.discount}% off ${tag(c.active?'verified':'rejected').replace(/VERIFIED|REJECTED/,c.active?'ACTIVE':'INACTIVE')}</div><div><button class="sm" data-t="${esc(c.code)}" data-a="${c.active?0:1}">${c.active?'Deactivate':'Activate'}</button> <button class="sm red" data-d="${esc(c.code)}">Delete</button></div></div>`).join('')||'<p class="muted">No coupons yet.</p>'}</div>`);
  $('#rb').onclick=run(async()=>{const d=await api('coupons/random','POST',{discount:Number($('#rp').value)});toast('Created '+d.code);go('coupons')});
  $('#cb').onclick=run(async()=>{await api('coupons','POST',{code:$('#cc').value,discount:Number($('#cp').value)});toast('Coupon created');go('coupons')});
  document.querySelectorAll('[data-t]').forEach(b=>b.onclick=run(async()=>{await api('coupons/'+b.dataset.t,'PATCH',{active:b.dataset.a==='1'});go('coupons')}));
  document.querySelectorAll('[data-d]').forEach(b=>b.onclick=run(async()=>{if(confirm('Delete coupon '+b.dataset.d+'?')){await api('coupons/'+b.dataset.d,'DELETE');go('coupons')}}))},
async announcements(){const rows=await api('announcements');set(`<h2>Live Announcements</h2><div class="panel"><h3>Create announcement</h3><textarea id="ann-new" maxlength="240" placeholder="Write a shop-wide announcement..."></textarea><label class="check"><input id="ann-new-active" type="checkbox" checked> Active immediately</label><button class="btn" id="ann-create">Publish announcement</button></div><div class="panel spaced"><h3>Existing announcements</h3>${rows.map(a=>`<div class="row ann-row" data-ann="${esc(a.id)}"><div><textarea data-ann-message maxlength="240">${esc(a.message)}</textarea><label><input type="checkbox" data-ann-active ${a.active?'checked':''}> Active</label></div><div><button class="sm" data-ann-save>Save</button> <button class="sm red" data-ann-delete>Delete</button></div></div>`).join('')||'<p class="muted">No announcements yet.</p>'}</div>`);
  $('#ann-create').onclick=run(async()=>{await api('announcements','POST',{message:$('#ann-new').value,active:$('#ann-new-active').checked});toast('Announcement published');go('announcements')});
  document.querySelectorAll('[data-ann]').forEach(el=>{el.querySelector('[data-ann-save]').onclick=run(async()=>{await api('announcements/'+el.dataset.ann,'PUT',{message:el.querySelector('[data-ann-message]').value,active:el.querySelector('[data-ann-active]').checked});toast('Announcement updated');go('announcements')});el.querySelector('[data-ann-delete]').onclick=run(async()=>{if(confirm('Delete this announcement?')){await api('announcements/'+el.dataset.ann,'DELETE');go('announcements')}})})},
async maintenance(){const m=await api('maintenance');
  set(`<h2>Maintenance Mode</h2><div class="panel"><div class="maint-head"><div><h3>Shop status: <span id="mt-state" class="mt-state ${m.enabled?'on':'off'}">${m.enabled?'MAINTENANCE ON':'SHOP LIVE'}</span></h3><p class="muted">${m.enabled?'Customers see the full-screen MAINTENANCE page. New orders are blocked.':'The shop is open and working normally.'}<br>Admin panel always stays accessible.${m.updatedAt?'<br>Last changed: '+esc(fmtD(m.updatedAt)):''}</p></div><label class="switch" title="Toggle Maintenance Mode"><input type="checkbox" id="mt-toggle" ${m.enabled?'checked':''}><span class="slider"></span></label></div></div>
  <div class="panel spaced"><h3>Maintenance reason / message</h3><p class="muted">Shown to customers on the maintenance screen. Changes apply instantly.</p><textarea id="mt-msg" maxlength="500" placeholder="Why is the shop under maintenance?">${esc(m.message)}</textarea><p class="muted"><span id="mt-count">${m.message.length}</span>/500</p><button class="btn" id="mt-save">Save message</button> <a class="btn ghost linkbtn" href="https://shop.xgencloud.bond" target="_blank" rel="noreferrer">Open shop ↗</a></div>`);
  const msg=$('#mt-msg');msg.oninput=()=>{$('#mt-count').textContent=msg.value.length};
  $('#mt-save').onclick=run(async()=>{if(!msg.value.trim())throw Error('Enter a maintenance reason/message.');await api('maintenance','PUT',{message:msg.value});toast('Message saved — live now');go('maintenance')});
  $('#mt-toggle').onchange=async e=>{const want=e.target.checked;try{if(want&&!confirm('Turn Maintenance Mode ON? Customers will immediately be blocked from the shop.')){e.target.checked=false;return}if(!msg.value.trim())throw Error('Enter a maintenance reason/message first.');await api('maintenance','PUT',{enabled:want,message:msg.value});toast(want?'Maintenance ON — shop closed':'Maintenance OFF — shop live');go('maintenance')}catch(err){e.target.checked=!want;toast(err.message)}}},
async settings(){const s=await api('settings');
  set(`<h2>Website Branding</h2><div class="panel"><h3>Website Logo</h3><p class="muted">Upload PNG, JPG or WebP (max 2 MB). Applies across the shop.</p><img id="logo-preview" class="media-preview" src="${s.logo_key?'/media/logo':''}" alt="Logo preview" ${s.logo_key?'':'hidden'}><input type="file" id="logo-file" accept="image/png,image/jpeg,image/webp"><button class="btn" id="logo-upload">Upload / Change Logo</button><button class="sm red" id="logo-remove">Remove Logo</button></div>
  <div class="panel spaced"><h3>Website Background</h3><p class="muted">Upload PNG, JPG or WebP (max 2 MB). Applies automatically to all shop pages.</p><img id="bg-preview" class="media-preview wide-preview" src="${s.background_key?'/media/background':''}" alt="Background preview" ${s.background_key?'':'hidden'}><input type="file" id="bg-file" accept="image/png,image/jpeg,image/webp"><button class="btn" id="bg-upload">Upload / Change Background</button><button class="sm red" id="bg-remove">Remove Background</button></div>
  <div class="panel spaced"><h3>Store settings</h3><p class="muted">UPI ID shown at payment (optional)</p><input id="su" value="${esc(s.upi_id||'')}" maxlength="100"><p class="muted">Discord invite link (used by every Discord button on the shop)</p><input id="sd" value="${esc(s.discord_invite||'https://discord.gg/kBHUk8FcB')}" maxlength="200" placeholder="https://discord.gg/..."><button class="btn" id="ss">Save settings</button></div>
  <div class="panel spaced"><h3>Payment QR Code</h3><p class="muted">Shown at checkout for UPI payment. Upload PNG, JPG or WebP (max 2 MB). ${s.payment_qr_key?'A custom QR is live on the shop.':'No custom QR uploaded — the shop is showing the built-in QR image.'}</p><img id="qr-preview" class="media-preview qr-preview" src="/media/payment-qr?v=${esc(s.payment_qr_version||'')}" alt="Payment QR preview" ${s.payment_qr_key?'':'hidden'}><input type="file" id="qr-file" accept="image/png,image/jpeg,image/webp"><button class="btn" id="qr-upload">Upload / Change QR</button><button class="sm red" id="qr-remove" ${s.payment_qr_key?'':'hidden'}>Remove QR (use built-in)</button></div>
  <div class="panel spaced"><h3>Change admin password</h3><p class="muted">The password is stored only as a secure hash. Use 8+ characters.</p><div class="fields"><label>Current password<input type="password" id="pw-cur" autocomplete="current-password"></label><label>New password<input type="password" id="pw-next" autocomplete="new-password"></label></div><button class="btn" id="pw-save">Change password</button></div>`);
  const upload=async(kind)=>{const file=$('#'+(kind==='logo'?'logo':'bg')+'-file').files[0];const err=imgOk(file);if(err)return toast(err);const dataUrl=await readImage(file);await api('media','POST',{kind,dataUrl});toast(kind==='logo'?'Logo updated':'Background updated');go('settings')};
  $('#logo-upload').onclick=run(()=>upload('logo'));$('#bg-upload').onclick=run(()=>upload('background'));
  $('#logo-remove').onclick=run(async()=>{if(confirm('Remove website logo?')){await api('media?kind=logo','DELETE');toast('Logo removed');go('settings')}});
  $('#bg-remove').onclick=run(async()=>{if(confirm('Remove website background?')){await api('media?kind=background','DELETE');toast('Background removed');go('settings')}});
  $('#qr-upload').onclick=run(async()=>{const f=$('#qr-file').files[0];const err=imgOk(f);if(err)throw Error(err);await api('media','POST',{kind:'payment_qr',dataUrl:await readImage(f)});toast('Payment QR updated — live on the shop now');go('settings')});
  $('#qr-remove').onclick=run(async()=>{if(confirm('Remove the custom QR? The shop will show the built-in QR image again.')){await api('media?kind=payment_qr','DELETE');toast('Custom QR removed');go('settings')}});
  $('#ss').onclick=run(async()=>{await api('settings','PUT',{upi_id:$('#su').value,banner:'',discord_invite:$('#sd').value});toast('Settings saved')});
  $('#pw-save').onclick=run(async()=>{if(!confirm('Change the admin password now?'))return;await api('password','PUT',{current:$('#pw-cur').value,next:$('#pw-next').value});$('#pw-cur').value='';$('#pw-next').value='';toast('Password changed')})},
async music(){const m=await api('music');
  const MAXMB=15,EXTS=['mp3','m4a','aac','wav','ogg','oga'],fmtSize=n=>n>=1048576?(n/1048576).toFixed(1)+' MB':Math.max(1,Math.round(n/1024))+' KB';
  if(musicPreviewUrl){URL.revokeObjectURL(musicPreviewUrl);musicPreviewUrl=''}
  let want=m.enabled;
  set(`<h2>Music Settings</h2>
  <div class="panel"><h3>Background music <span id="mu-state" class="mu-state ${m.enabled?'on':'off'}">${m.enabled?'ON':'OFF'}</span></h3>
  <p class="muted">When ON, the track plays automatically and loops forever for every shop visitor. Visitors get no music controls. Some browsers wait for the visitor's first tap or click before sound can start.</p>
  <div class="seg" id="mu-seg" role="group" aria-label="Background music"><button type="button" data-en="1" class="${m.enabled?'on':''}">Enable Music</button><button type="button" data-en="0" class="${m.enabled?'':'on'}">Disable Music</button></div></div>
  <div class="panel spaced"><h3>Current Music</h3>${m.hasFile?`<p class="mu-file"><b>${esc(m.name)}</b><br><span class="muted">${esc({'audio/mpeg':'MP3','audio/mp4':'M4A','audio/aac':'AAC','audio/wav':'WAV','audio/ogg':'OGG'}[m.type]||'AUDIO')} · ${fmtSize(m.size)}${m.updatedAt?' · uploaded '+esc(fmtD(m.updatedAt)):''}</span></p><span class="muted">Music Preview (plays only here, not on the shop)</span><audio class="mu-player" id="mu-current" controls preload="none" src="/api/admin/music/file?v=${encodeURIComponent(m.version)}"></audio>`:'<p class="muted">No music uploaded yet.</p>'}</div>
  <div class="panel spaced"><h3>Change Music</h3><p class="muted">Upload MP3, M4A/AAC, WAV or OGG (max ${MAXMB} MB). MP3 is recommended because it plays on every phone and browser. The new file replaces the current one when you press Save Settings.</p>
  <input type="file" id="mu-file" accept="audio/mpeg,audio/mp4,audio/aac,audio/wav,audio/ogg,.mp3,.m4a,.aac,.wav,.ogg,.oga">
  <div id="mu-sel" hidden><p class="mu-file">Selected: <b id="mu-selname"></b> <span class="muted" id="mu-selmeta"></span></p><span class="muted">Preview before saving</span><audio class="mu-player" id="mu-selplayer" controls preload="metadata"></audio></div></div>
  <div class="spaced"><button class="btn" id="mu-save">Save Settings</button></div>`);
  const seg=$('#mu-seg');
  seg.onclick=e=>{const b=e.target.closest('[data-en]');if(!b)return;want=b.dataset.en==='1';seg.querySelectorAll('[data-en]').forEach(x=>x.classList.toggle('on',x===b))};
  const fileIn=$('#mu-file'),sel=$('#mu-sel'),player=$('#mu-selplayer');
  const bad=f=>{const ext=(f.name.split('.').pop()||'').toLowerCase();if(!EXTS.includes(ext))return'Choose an MP3, M4A, AAC, WAV or OGG file.';if(f.size>MAXMB*1048576)return`File is ${fmtSize(f.size)}. The limit is ${MAXMB} MB.`;if(!f.size)return'That file is empty.';return''};
  fileIn.onchange=()=>{const f=fileIn.files[0];if(musicPreviewUrl){URL.revokeObjectURL(musicPreviewUrl);musicPreviewUrl=''}player.removeAttribute('src');player.load();
    if(!f){sel.hidden=true;return}
    const err=bad(f);if(err){fileIn.value='';sel.hidden=true;toast(err);return}
    musicPreviewUrl=URL.createObjectURL(f);player.src=musicPreviewUrl;$('#mu-selname').textContent=f.name;$('#mu-selmeta').textContent='· '+fmtSize(f.size);sel.hidden=false};
  $('#mu-save').onclick=async()=>{const btn=$('#mu-save'),f=fileIn.files[0];
    try{
      if(f){const err=bad(f);if(err)throw Error(err)}
      if(want&&!f&&!m.hasFile)throw Error('Upload a music file before enabling background music.');
      if(!f&&want===m.enabled)return toast('No changes to save');
      btn.disabled=true;btn.textContent=f?'Uploading…':'Saving…';
      if(f){const r=await fetch('/api/admin/music/upload',{method:'POST',headers:{'Content-Type':'application/octet-stream','X-XGEN-Admin':'1','X-File-Name':encodeURIComponent(f.name)},body:f});
        const d=await r.json().catch(()=>({}));if(r.status===401){lock();throw Error('Session expired. Please sign in again.')}if(!r.ok)throw Error(d.error||'Upload failed')}
      await api('music','PUT',{enabled:want});
      toast(want?'Music saved — playing on the shop now':'Music saved — background music is OFF');
    }catch(e){toast(e.message)}
    finally{if(tab==='music')go('music')}}
}

};
document.querySelectorAll('#nav button').forEach(b=>b.onclick=()=>go(b.dataset.tab));
$('#logout').onclick=async()=>{await api('logout','POST').catch(()=>{});lock()};
$('#login-form').onsubmit=async e=>{e.preventDefault();$('#login-msg').textContent='';
  try{await api('login','POST',{password:$('#pw').value});$('#pw').value='';unlock()}catch(err){$('#login-msg').textContent=err.message}};
api('me').then(unlock).catch(()=>{});
